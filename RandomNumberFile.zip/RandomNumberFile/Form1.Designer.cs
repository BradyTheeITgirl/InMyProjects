﻿namespace RandomNumberFile
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            instructionsLabel = new Label();
            numberCountTextBox = new TextBox();
            saveButton = new Button();
            openButton = new Button();
            numbersListBox = new ListBox();
            saveFileDialog1 = new SaveFileDialog();
            openFileDialog1 = new OpenFileDialog();
            totalPromptLabel = new Label();
            totalLabel = new Label();
            countPromptLabel = new Label();
            countLabel = new Label();
            SuspendLayout();
            // 
            // instructionsLabel
            // 
            instructionsLabel.AutoSize = true;
            instructionsLabel.Location = new Point(12, 9);
            instructionsLabel.Name = "instructionsLabel";
            instructionsLabel.Size = new Size(251, 15);
            instructionsLabel.TabIndex = 0;
            instructionsLabel.Text = "Enter the number of random numbers to save:";
            // 
            // numberCountTextBox
            // 
            numberCountTextBox.Location = new Point(20, 31);
            numberCountTextBox.Name = "numberCountTextBox";
            numberCountTextBox.Size = new Size(100, 23);
            numberCountTextBox.TabIndex = 1;
            // 
            // saveButton
            // 
            saveButton.Location = new Point(20, 60);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(100, 41);
            saveButton.TabIndex = 2;
            saveButton.Text = "Generate and Save Numbers";
            saveButton.UseVisualStyleBackColor = true;
            // 
            // openButton
            // 
            openButton.Location = new Point(640, 12);
            openButton.Name = "openButton";
            openButton.Size = new Size(75, 23);
            openButton.TabIndex = 3;
            openButton.Text = "Open File";
            openButton.UseVisualStyleBackColor = true;
            // 
            // numbersListBox
            // 
            numbersListBox.FormattingEnabled = true;
            numbersListBox.Location = new Point(445, 12);
            numbersListBox.Name = "numbersListBox";
            numbersListBox.Size = new Size(167, 319);
            numbersListBox.TabIndex = 4;
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // totalPromptLabel
            // 
            totalPromptLabel.AutoSize = true;
            totalPromptLabel.Location = new Point(640, 39);
            totalPromptLabel.Name = "totalPromptLabel";
            totalPromptLabel.Size = new Size(35, 15);
            totalPromptLabel.TabIndex = 5;
            totalPromptLabel.Text = "Total:";
            // 
            // totalLabel
            // 
            totalLabel.BorderStyle = BorderStyle.FixedSingle;
            totalLabel.Location = new Point(677, 39);
            totalLabel.Name = "totalLabel";
            totalLabel.Size = new Size(100, 23);
            totalLabel.TabIndex = 6;
            totalLabel.TextAlign = ContentAlignment.MiddleCenter;
            totalLabel.Click += label1_Click;
            // 
            // countPromptLabel
            // 
            countPromptLabel.AutoSize = true;
            countPromptLabel.Location = new Point(632, 73);
            countPromptLabel.Name = "countPromptLabel";
            countPromptLabel.Size = new Size(43, 15);
            countPromptLabel.TabIndex = 7;
            countPromptLabel.Text = "Count:";
            // 
            // countLabel
            // 
            countLabel.BorderStyle = BorderStyle.FixedSingle;
            countLabel.Location = new Point(677, 73);
            countLabel.Name = "countLabel";
            countLabel.Size = new Size(100, 23);
            countLabel.TabIndex = 8;
            countLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(countLabel);
            Controls.Add(countPromptLabel);
            Controls.Add(totalLabel);
            Controls.Add(totalPromptLabel);
            Controls.Add(numbersListBox);
            Controls.Add(openButton);
            Controls.Add(saveButton);
            Controls.Add(numberCountTextBox);
            Controls.Add(instructionsLabel);
            Name = "Form1";
            Text = "Random Number File";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label instructionsLabel;
        private TextBox numberCountTextBox;
        private Button saveButton;
        private Button openButton;
        private ListBox numbersListBox;
        private SaveFileDialog saveFileDialog1;
        private OpenFileDialog openFileDialog1;
        private Label totalPromptLabel;
        private Label totalLabel;
        private Label countPromptLabel;
        private Label countLabel;
    }
}
