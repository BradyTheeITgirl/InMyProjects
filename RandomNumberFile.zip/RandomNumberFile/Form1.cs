namespace RandomNumberFile
{
    public partial class Form1 : Form
    {
        // Class-level Random so you don't re-seed it every click
        private readonly Random random = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        // PART 1: Generate and Save Random Numbers
        private void saveButton_Click(object sender, EventArgs e)
        {
            // Validate input
            if (!int.TryParse(numberCountTextBox.Text, out int maxNumbers) || maxNumbers <= 0)
            {
                MessageBox.Show("Please enter a valid number.");
                numberCountTextBox.Focus();
                numberCountTextBox.SelectAll();
                return;
            }

            // Configure dialog (optional but nice)
            saveFileDialog1.Title = "Save Random Numbers";
            saveFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            saveFileDialog1.FileName = "RandomNumbers.txt";

            // Show dialog
            if (saveFileDialog1.ShowDialog() != DialogResult.OK)
            {
                MessageBox.Show("Operation canceled.");
                return;
            }

            string filename = saveFileDialog1.FileName;

            try
            {
                using (StreamWriter outputFile = File.CreateText(filename))
                {
                    for (int i = 0; i < maxNumbers; i++)
                    {
                        int number = random.Next(1, 101); // 1 to 100
                        outputFile.WriteLine(number);
                    }
                }

                MessageBox.Show($"{maxNumbers} random numbers written to:\n{filename}");
                numberCountTextBox.Clear();
                numberCountTextBox.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // PART 2: Open File and Display Numbers
        private void openButton_Click(object sender, EventArgs e)
        {
            int sum = 0;
            int count = 0;

            // Configure dialog (optional but nice)
            openFileDialog1.Title = "Open Random Numbers File";
            openFileDialog1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";

            if (openFileDialog1.ShowDialog() != DialogResult.OK)
            {
                MessageBox.Show("Operation canceled.");
                return;
            }

            string filename = openFileDialog1.FileName;

            numbersListBox.Items.Clear();
            totalLabel.Text = "";
            countLabel.Text = "";

            try
            {
                using (StreamReader inputFile = File.OpenText(filename))
                {
                    while (!inputFile.EndOfStream)
                    {
                        string line = inputFile.ReadLine();

                        // Skip blank lines safely
                        if (string.IsNullOrWhiteSpace(line))
                            continue;

                        // Parse numbers safely
                        if (int.TryParse(line, out int number))
                        {
                            numbersListBox.Items.Add(number);
                            sum += number;
                            count++;
                        }
                        else
                        {
                            // If the file contains a bad line, notify but keep reading
                            numbersListBox.Items.Add($"Invalid: {line}");
                        }
                    }
                }

                totalLabel.Text = sum.ToString();
                countLabel.Text = count.ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}