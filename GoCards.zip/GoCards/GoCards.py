# GoCards.py
# Prints numbers from 1 to 100
# Multiples of 4 print "Go"
# Multiples of 7 print "Cards"
# Multiples of both 4 and 7 print "Go Cards"

for number in range(1, 101):
    if number % 4 == 0 and number % 7 == 0:
        print("Go Cards")
    elif number % 4 == 0:
        print("Go")
    elif number % 7 == 0:
        print("Cards")
    else:
        print(number)

