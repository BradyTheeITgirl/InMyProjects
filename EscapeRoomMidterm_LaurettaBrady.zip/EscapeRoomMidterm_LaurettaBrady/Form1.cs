using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace DigitalEscapeRoom
{
    public partial class Form1 : Form
    {
        // Track solved puzzles
        private bool puzzle1Solved = false;
        private bool puzzle2Solved = false;
        private bool puzzle3Solved = false;

        // Hint system
        private int hintsRemaining = 3;

        // Store correct answers in a List
        private List<string> finalWords = new List<string> { "SUN", "42", "KEY" };

        // Store player action history
        private List<string> history = new List<string>();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ResetGame();
        }

        private void ResetGame()
        {
            puzzle1Solved = false;
            puzzle2Solved = false;
            puzzle3Solved = false;
            hintsRemaining = 3;

            txtPuzzle1.Text = "";
            txtPuzzle2.Text = "";
            txtPuzzle3.Text = "";
            txtFinalCode.Text = "";

            txtPuzzle1.Enabled = true;
            txtPuzzle2.Enabled = true;
            txtPuzzle3.Enabled = true;

            btnPuzzle1.Enabled = true;
            btnPuzzle2.Enabled = true;
            btnPuzzle3.Enabled = true;

            grpFinal.Enabled = false;

            lstHistory.Items.Clear();
            history.Clear();

            lblTitle.Text = "Digital Escape Room";
            lblInstructions.Text = "Solve all 3 puzzles to reveal the final escape code.";
            lblStatus.Text = "You are locked in the room...";
            lblHintsRemaining.Text = "Hints Remaining: " + hintsRemaining;

            lblPuzzle1.Text = "Puzzle 1: I rise in the east and set in the west. What am I?";
            lblPuzzle2.Text = "Puzzle 2: What number is the answer to life, the universe, and everything?";
            lblPuzzle3.Text = "Puzzle 3: I open locks but I am not a password. What am I?";

            lblFinalClue.Text = "Final Code: Combine the 3 puzzle answers with hyphens.\nExample: ANSWER1-ANSWER2-ANSWER3";
        }

        private bool ValidateAnswer(TextBox textBox, string puzzleName)
        {
            if (string.IsNullOrWhiteSpace(textBox.Text))
            {
                MessageBox.Show("Please enter an answer for " + puzzleName + ".", "Missing Input");
                return false;
            }

            return true;
        }

        private void AddHistory(string message)
        {
            history.Add(message);
            lstHistory.Items.Add(message);
        }

        private void CheckAllSolved()
        {
            if (puzzle1Solved && puzzle2Solved && puzzle3Solved)
            {
                grpFinal.Enabled = true;
                lblStatus.Text = "All puzzles solved! Enter the final escape code.";
                AddHistory("All three puzzles solved. Final panel unlocked.");
            }
        }

        private string BuildExpectedFinalCode()
        {
            string code = "";

            // Required loop usage
            for (int i = 0; i < finalWords.Count; i++)
            {
                code += finalWords[i];

                if (i < finalWords.Count - 1)
                {
                    code += "-";
                }
            }

            return code;
        }

        private void btnPuzzle1_Click(object sender, EventArgs e)
        {
            if (!ValidateAnswer(txtPuzzle1, "Puzzle 1"))
                return;

            string answer = txtPuzzle1.Text.Trim().ToUpper();

            if (answer == "SUN")
            {
                puzzle1Solved = true;
                txtPuzzle1.Enabled = false;
                btnPuzzle1.Enabled = false;
                lblStatus.Text = "Puzzle 1 solved!";
                AddHistory("Puzzle 1 solved with answer: " + answer);
            }
            else
            {
                lblStatus.Text = "Puzzle 1 incorrect. Try again.";
                AddHistory("Puzzle 1 failed attempt: " + answer);
            }

            CheckAllSolved();
        }

        private void btnPuzzle2_Click(object sender, EventArgs e)
        {
            try
            {
                if (!ValidateAnswer(txtPuzzle2, "Puzzle 2"))
                    return;

                int number = int.Parse(txtPuzzle2.Text.Trim());

                if (number == 42)
                {
                    puzzle2Solved = true;
                    txtPuzzle2.Enabled = false;
                    btnPuzzle2.Enabled = false;
                    lblStatus.Text = "Puzzle 2 solved!";
                    AddHistory("Puzzle 2 solved with answer: " + number);
                }
                else
                {
                    lblStatus.Text = "Puzzle 2 incorrect. Try again.";
                    AddHistory("Puzzle 2 failed attempt: " + number);
                }

                CheckAllSolved();
            }
            catch (FormatException)
            {
                lblStatus.Text = "Puzzle 2 requires a number.";
                MessageBox.Show("Please enter a valid whole number for Puzzle 2.", "Input Error");
                AddHistory("Puzzle 2 invalid input.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Unexpected error: " + ex.Message, "Error");
                AddHistory("Puzzle 2 unexpected error.");
            }
        }

        private void btnPuzzle3_Click(object sender, EventArgs e)
        {
            if (!ValidateAnswer(txtPuzzle3, "Puzzle 3"))
                return;

            string answer = txtPuzzle3.Text.Trim().ToUpper();

            // Array of acceptable answers
            string[] acceptableAnswers = { "KEY", "A KEY" };

            bool correct = false;

            foreach (string item in acceptableAnswers)
            {
                if (answer == item)
                {
                    correct = true;
                    break;
                }
            }

            if (correct)
            {
                puzzle3Solved = true;
                txtPuzzle3.Enabled = false;
                btnPuzzle3.Enabled = false;
                lblStatus.Text = "Puzzle 3 solved!";
                AddHistory("Puzzle 3 solved with answer: " + answer);
            }
            else
            {
                lblStatus.Text = "Puzzle 3 incorrect. Try again.";
                AddHistory("Puzzle 3 failed attempt: " + answer);
            }

            CheckAllSolved();
        }

        private void btnEscape_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFinalCode.Text))
            {
                MessageBox.Show("Enter the final code before trying to escape.", "Missing Code");
                return;
            }

            string playerCode = txtFinalCode.Text.Trim().ToUpper();
            string expectedCode = BuildExpectedFinalCode();

            if (playerCode == expectedCode)
            {
                lblStatus.Text = "Congratulations! You escaped the room!";
                MessageBox.Show("Victory! The door unlocks and you escape!", "You Win");
                AddHistory("Player escaped successfully with code: " + playerCode);
            }
            else
            {
                lblStatus.Text = "That final code is incorrect.";
                AddHistory("Failed final code attempt: " + playerCode);
            }
        }

        private void btnHint_Click(object sender, EventArgs e)
        {
            if (hintsRemaining <= 0)
            {
                MessageBox.Show("No hints remaining.", "Hints");
                return;
            }

            hintsRemaining--;
            lblHintsRemaining.Text = "Hints Remaining: " + hintsRemaining;

            if (!puzzle1Solved)
            {
                MessageBox.Show("Puzzle 1 Hint: It shines during the day.", "Hint");
                AddHistory("Used hint for Puzzle 1.");
            }
            else if (!puzzle2Solved)
            {
                MessageBox.Show("Puzzle 2 Hint: Think science fiction and Douglas Adams.", "Hint");
                AddHistory("Used hint for Puzzle 2.");
            }
            else if (!puzzle3Solved)
            {
                MessageBox.Show("Puzzle 3 Hint: It fits in a lock.", "Hint");
                AddHistory("Used hint for Puzzle 3.");
            }
            else
            {
                MessageBox.Show("Final Code Hint: Combine the three solved answers with hyphens.", "Hint");
                AddHistory("Used hint for final code.");
            }
        }

        private void btnRestart_Click(object sender, EventArgs e)
        {
            ResetGame();
            AddHistory("Game restarted.");
        }
    }
}
