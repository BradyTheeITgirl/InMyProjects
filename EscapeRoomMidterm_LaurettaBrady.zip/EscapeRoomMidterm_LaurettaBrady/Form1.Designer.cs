﻿namespace DigitalEscapeRoom
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblInstructions = new Label();
            lblStatus = new Label();
            btnPuzzle1 = new Button();
            btnPuzzle2 = new Button();
            btnPuzzle3 = new Button();
            btnEscape = new Button();
            btnHint = new Button();
            btnRestart = new Button();
            txtPuzzle1 = new TextBox();
            txtPuzzle2 = new TextBox();
            txtPuzzle3 = new TextBox();
            txtFinalCode = new TextBox();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Location = new Point(306, 19);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(115, 15);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Digital Escape Room";
            // 
            // lblInstructions
            // 
            lblInstructions.AutoSize = true;
            lblInstructions.Location = new Point(182, 53);
            lblInstructions.Name = "lblInstructions";
            lblInstructions.Size = new Size(265, 15);
            lblInstructions.TabIndex = 1;
            lblInstructions.Text = "Solve all 3 puzzles to reveal the final escape code.";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(336, 78);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(158, 15);
            lblStatus.TabIndex = 2;
            lblStatus.Text = "You are locked in the room...";
            // 
            // btnPuzzle1
            // 
            btnPuzzle1.Location = new Point(99, 123);
            btnPuzzle1.Name = "btnPuzzle1";
            btnPuzzle1.Size = new Size(75, 23);
            btnPuzzle1.TabIndex = 3;
            btnPuzzle1.Text = "Submit";
            btnPuzzle1.UseVisualStyleBackColor = true;
            // 
            // btnPuzzle2
            // 
            btnPuzzle2.Location = new Point(326, 123);
            btnPuzzle2.Name = "btnPuzzle2";
            btnPuzzle2.Size = new Size(75, 23);
            btnPuzzle2.TabIndex = 4;
            btnPuzzle2.Text = "Submit";
            btnPuzzle2.UseVisualStyleBackColor = true;
            // 
            // btnPuzzle3
            // 
            btnPuzzle3.Location = new Point(518, 123);
            btnPuzzle3.Name = "btnPuzzle3";
            btnPuzzle3.Size = new Size(75, 23);
            btnPuzzle3.TabIndex = 5;
            btnPuzzle3.Text = "Submit";
            btnPuzzle3.UseVisualStyleBackColor = true;
            // 
            // btnEscape
            // 
            btnEscape.Location = new Point(99, 246);
            btnEscape.Name = "btnEscape";
            btnEscape.Size = new Size(75, 23);
            btnEscape.TabIndex = 6;
            btnEscape.Text = "Escape";
            btnEscape.UseVisualStyleBackColor = true;
            // 
            // btnHint
            // 
            btnHint.Location = new Point(326, 246);
            btnHint.Name = "btnHint";
            btnHint.Size = new Size(75, 23);
            btnHint.TabIndex = 7;
            btnHint.Text = "Hint";
            btnHint.UseVisualStyleBackColor = true;
            // 
            // btnRestart
            // 
            btnRestart.Location = new Point(518, 246);
            btnRestart.Name = "btnRestart";
            btnRestart.Size = new Size(75, 23);
            btnRestart.TabIndex = 8;
            btnRestart.Text = "Restart";
            btnRestart.UseVisualStyleBackColor = true;
            // 
            // txtPuzzle1
            // 
            txtPuzzle1.Location = new Point(74, 173);
            txtPuzzle1.Name = "txtPuzzle1";
            txtPuzzle1.Size = new Size(100, 23);
            txtPuzzle1.TabIndex = 9;
            // 
            // txtPuzzle2
            // 
            txtPuzzle2.Location = new Point(301, 173);
            txtPuzzle2.Name = "txtPuzzle2";
            txtPuzzle2.Size = new Size(100, 23);
            txtPuzzle2.TabIndex = 10;
            // 
            // txtPuzzle3
            // 
            txtPuzzle3.Location = new Point(493, 173);
            txtPuzzle3.Name = "txtPuzzle3";
            txtPuzzle3.Size = new Size(100, 23);
            txtPuzzle3.TabIndex = 11;
            // 
            // txtFinalCode
            // 
            txtFinalCode.Location = new Point(674, 173);
            txtFinalCode.Name = "txtFinalCode";
            txtFinalCode.Size = new Size(100, 23);
            txtFinalCode.TabIndex = 12;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtFinalCode);
            Controls.Add(txtPuzzle3);
            Controls.Add(txtPuzzle2);
            Controls.Add(txtPuzzle1);
            Controls.Add(btnRestart);
            Controls.Add(btnHint);
            Controls.Add(btnEscape);
            Controls.Add(btnPuzzle3);
            Controls.Add(btnPuzzle2);
            Controls.Add(btnPuzzle1);
            Controls.Add(lblStatus);
            Controls.Add(lblInstructions);
            Controls.Add(lblTitle);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblTitle;
        private Label lblInstructions;
        private Label lblStatus;
        private Button btnPuzzle1;
        private Button btnPuzzle2;
        private Button btnPuzzle3;
        private Button btnEscape;
        private Button btnHint;
        private Button btnRestart;
        private TextBox txtPuzzle1;
        private TextBox txtPuzzle2;
        private TextBox txtPuzzle3;
        private TextBox txtFinalCode;
    }
}
