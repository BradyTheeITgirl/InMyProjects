﻿namespace Distance_Converter
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            distancePromptLabel = new Label();
            distanceTextBox = new TextBox();
            fromGroupBox = new GroupBox();
            yardsFromRadioButton = new RadioButton();
            feetFromRadioButton = new RadioButton();
            inchesFromRadioButton = new RadioButton();
            toGroupBox = new GroupBox();
            yardsToRadioButton = new RadioButton();
            feetToRadioButton = new RadioButton();
            inchesToRadioButton = new RadioButton();
            convertedDistancePromptLabel = new Label();
            convertedDistanceLabel = new Label();
            convertButton = new Button();
            exitButton = new Button();
            fromGroupBox.SuspendLayout();
            toGroupBox.SuspendLayout();
            SuspendLayout();
            // 
            // distancePromptLabel
            // 
            distancePromptLabel.AutoSize = true;
            distancePromptLabel.Location = new Point(63, 20);
            distancePromptLabel.Name = "distancePromptLabel";
            distancePromptLabel.Size = new Size(147, 15);
            distancePromptLabel.TabIndex = 0;
            distancePromptLabel.Text = "Enter a distance to convert";
            // 
            // distanceTextBox
            // 
            distanceTextBox.Location = new Point(228, 20);
            distanceTextBox.Name = "distanceTextBox";
            distanceTextBox.Size = new Size(100, 23);
            distanceTextBox.TabIndex = 1;
            // 
            // fromGroupBox
            // 
            fromGroupBox.Controls.Add(yardsFromRadioButton);
            fromGroupBox.Controls.Add(feetFromRadioButton);
            fromGroupBox.Controls.Add(inchesFromRadioButton);
            fromGroupBox.Location = new Point(12, 55);
            fromGroupBox.Name = "fromGroupBox";
            fromGroupBox.Size = new Size(200, 243);
            fromGroupBox.TabIndex = 2;
            fromGroupBox.TabStop = false;
            fromGroupBox.Text = "From";
            // 
            // yardsFromRadioButton
            // 
            yardsFromRadioButton.AutoSize = true;
            yardsFromRadioButton.Location = new Point(18, 123);
            yardsFromRadioButton.Name = "yardsFromRadioButton";
            yardsFromRadioButton.Size = new Size(53, 19);
            yardsFromRadioButton.TabIndex = 2;
            yardsFromRadioButton.TabStop = true;
            yardsFromRadioButton.Text = "Yards";
            yardsFromRadioButton.UseVisualStyleBackColor = true;
            // 
            // feetFromRadioButton
            // 
            feetFromRadioButton.AutoSize = true;
            feetFromRadioButton.Location = new Point(17, 87);
            feetFromRadioButton.Name = "feetFromRadioButton";
            feetFromRadioButton.Size = new Size(47, 19);
            feetFromRadioButton.TabIndex = 1;
            feetFromRadioButton.TabStop = true;
            feetFromRadioButton.Text = "Feet";
            feetFromRadioButton.UseVisualStyleBackColor = true;
            // 
            // inchesFromRadioButton
            // 
            inchesFromRadioButton.AutoSize = true;
            inchesFromRadioButton.Location = new Point(17, 49);
            inchesFromRadioButton.Name = "inchesFromRadioButton";
            inchesFromRadioButton.Size = new Size(59, 19);
            inchesFromRadioButton.TabIndex = 0;
            inchesFromRadioButton.TabStop = true;
            inchesFromRadioButton.Text = "Inches";
            inchesFromRadioButton.UseVisualStyleBackColor = true;
            // 
            // toGroupBox
            // 
            toGroupBox.Controls.Add(yardsToRadioButton);
            toGroupBox.Controls.Add(feetToRadioButton);
            toGroupBox.Controls.Add(inchesToRadioButton);
            toGroupBox.Location = new Point(241, 61);
            toGroupBox.Name = "toGroupBox";
            toGroupBox.Size = new Size(200, 237);
            toGroupBox.TabIndex = 3;
            toGroupBox.TabStop = false;
            toGroupBox.Text = "To";
            // 
            // yardsToRadioButton
            // 
            yardsToRadioButton.AutoSize = true;
            yardsToRadioButton.Location = new Point(15, 117);
            yardsToRadioButton.Name = "yardsToRadioButton";
            yardsToRadioButton.Size = new Size(53, 19);
            yardsToRadioButton.TabIndex = 2;
            yardsToRadioButton.TabStop = true;
            yardsToRadioButton.Text = "Yards";
            yardsToRadioButton.UseVisualStyleBackColor = true;
            // 
            // feetToRadioButton
            // 
            feetToRadioButton.AutoSize = true;
            feetToRadioButton.Location = new Point(15, 81);
            feetToRadioButton.Name = "feetToRadioButton";
            feetToRadioButton.Size = new Size(47, 19);
            feetToRadioButton.TabIndex = 1;
            feetToRadioButton.TabStop = true;
            feetToRadioButton.Text = "Feet";
            feetToRadioButton.UseVisualStyleBackColor = true;
            // 
            // inchesToRadioButton
            // 
            inchesToRadioButton.AutoSize = true;
            inchesToRadioButton.Location = new Point(15, 43);
            inchesToRadioButton.Name = "inchesToRadioButton";
            inchesToRadioButton.Size = new Size(59, 19);
            inchesToRadioButton.TabIndex = 0;
            inchesToRadioButton.TabStop = true;
            inchesToRadioButton.Text = "Inches";
            inchesToRadioButton.UseVisualStyleBackColor = true;
            // 
            // convertedDistancePromptLabel
            // 
            convertedDistancePromptLabel.AutoSize = true;
            convertedDistancePromptLabel.Location = new Point(12, 316);
            convertedDistancePromptLabel.Name = "convertedDistancePromptLabel";
            convertedDistancePromptLabel.Size = new Size(143, 15);
            convertedDistancePromptLabel.TabIndex = 4;
            convertedDistancePromptLabel.Text = "The converted distance is:";
            // 
            // convertedDistanceLabel
            // 
            convertedDistanceLabel.BorderStyle = BorderStyle.FixedSingle;
            convertedDistanceLabel.Location = new Point(241, 316);
            convertedDistanceLabel.Name = "convertedDistanceLabel";
            convertedDistanceLabel.Size = new Size(100, 23);
            convertedDistanceLabel.TabIndex = 5;
            convertedDistanceLabel.Text = "\"\"";
            convertedDistanceLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // convertButton
            // 
            convertButton.Location = new Point(89, 344);
            convertButton.Name = "convertButton";
            convertButton.Size = new Size(75, 23);
            convertButton.TabIndex = 6;
            convertButton.Text = "Convert";
            convertButton.UseVisualStyleBackColor = true;
            convertButton.Click += convertButton_Click;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(241, 344);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(75, 23);
            exitButton.TabIndex = 7;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            exitButton.Click += exitButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(exitButton);
            Controls.Add(convertButton);
            Controls.Add(convertedDistanceLabel);
            Controls.Add(convertedDistancePromptLabel);
            Controls.Add(toGroupBox);
            Controls.Add(fromGroupBox);
            Controls.Add(distanceTextBox);
            Controls.Add(distancePromptLabel);
            Name = "Form1";
            Text = "Form1";
            fromGroupBox.ResumeLayout(false);
            fromGroupBox.PerformLayout();
            toGroupBox.ResumeLayout(false);
            toGroupBox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label distancePromptLabel;
        private TextBox distanceTextBox;
        private GroupBox fromGroupBox;
        private RadioButton inchesFromRadioButton;
        private RadioButton yardsFromRadioButton;
        private RadioButton feetFromRadioButton;
        private GroupBox toGroupBox;
        private RadioButton inchesToRadioButton;
        private RadioButton yardsToRadioButton;
        private RadioButton feetToRadioButton;
        private Label convertedDistancePromptLabel;
        private Label convertedDistanceLabel;
        private Button convertButton;
        private Button exitButton;
    }
}
