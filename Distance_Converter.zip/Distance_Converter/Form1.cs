﻿namespace Distance_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            // Declare required variables
            double originalDistance;
            double convertedDistance = 0;

            // Safely convert input using TryParse
            if (!double.TryParse(distanceTextBox.Text, out originalDistance))
            {
                MessageBox.Show(
                    "Please enter a valid numeric distance.",
                    "Invalid Input",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);

                distanceTextBox.Focus();
                distanceTextBox.SelectAll();
                return;
            }

            // SAME UNIT CHECK (From == To)
            if ((inchesFromRadioButton.Checked && inchesToRadioButton.Checked) ||
                (feetFromRadioButton.Checked && feetToRadioButton.Checked) ||
                (yardsFromRadioButton.Checked && yardsToRadioButton.Checked))
            {
                convertedDistance = originalDistance;
            }
            else
            {
                // Conversion logic using AND (&&) and nested ifs

                // Inches → Feet
                if (inchesFromRadioButton.Checked && feetToRadioButton.Checked)
                    convertedDistance = originalDistance / 12;

                // Inches → Yards
                else if (inchesFromRadioButton.Checked && yardsToRadioButton.Checked)
                    convertedDistance = originalDistance / 36;

                // Feet → Inches
                else if (feetFromRadioButton.Checked && inchesToRadioButton.Checked)
                    convertedDistance = originalDistance * 12;

                // Feet → Yards
                else if (feetFromRadioButton.Checked && yardsToRadioButton.Checked)
                    convertedDistance = originalDistance / 3;

                // Yards → Inches
                else if (yardsFromRadioButton.Checked && inchesToRadioButton.Checked)
                    convertedDistance = originalDistance * 36;

                // Yards → Feet
                else if (yardsFromRadioButton.Checked && feetToRadioButton.Checked)
                    convertedDistance = originalDistance * 3;
            }

            // Display formatted result
            convertedDistanceLabel.Text = convertedDistance.ToString("F2");
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
