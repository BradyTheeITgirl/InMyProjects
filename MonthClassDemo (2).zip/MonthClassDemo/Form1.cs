using MonthClassDemo;

private Month currentMonth;

private void createByNumberButton_Click(object sender, EventArgs e)
{
    if (int.TryParse(monthNumberTextBox.Text, out int number))
    {
        currentMonth = new Month(number);
        UpdateDisplay();
    }
    else
    {
        MessageBox.Show("Please enter a valid month number.");
    }
}

private void createByNameButton_Click(object sender, EventArgs e)
{
    string name = monthNameTextBox.Text.Trim();
    if (!string.IsNullOrEmpty(name))
    {
        currentMonth = new Month(name);
        UpdateDisplay();
    }
    else
    {
        MessageBox.Show("Please enter a valid month name.");
    }
}

private void useDefaultButton_Click(object sender, EventArgs e)
{
    currentMonth = new Month();
    UpdateDisplay();
}

private void copyButton_Click(object sender, EventArgs e)
{
    if (currentMonth != null)
    {
        currentMonth = new Month(currentMonth);
        UpdateDisplay();
    }
}

private void greaterThanButton_Click(object sender, EventArgs e)
{
    if (int.TryParse(compareToTextBox.Text, out int compareNumber))
    {
        Month other = new Month(compareNumber);
        compareResultLabel.Text = currentMonth.GreaterThan(other).ToString();
    }
    else
    {
        MessageBox.Show("Enter a valid month number to compare.");
    }
}

private void lessThanButton_Click(object sender, EventArgs e)
{
    if (int.TryParse(compareToTextBox.Text, out int compareNumber))
    {
        Month other = new Month(compareNumber);
        compareResultLabel.Text = currentMonth.LessThan(other).ToString();
    }
    else
    {
        MessageBox.Show("Enter a valid month number to compare.");
    }
}

private void UpdateDisplay()
{
    if (currentMonth != null)
    {
        displayNumberLabel.Text = currentMonth.MonthNumber.ToString();
        displayNameLabel.Text = currentMonth.MonthName;
        toStringLabel.Text = currentMonth.ToString();
    }
}
