﻿namespace MonthClassDemo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            enterGroupBox = new GroupBox();
            monthNameTextBox = new TextBox();
            monthNameLabel = new Label();
            monthNumberTextBox = new TextBox();
            monthNumberLabel = new Label();
            createByNumberButton = new Button();
            createByNameButton = new Button();
            useDefaultButton = new Button();
            copyButton = new Button();
            displayGroupBox = new GroupBox();
            toStringLabel = new Label();
            toStringPromptLabel = new Label();
            displayNameLabel = new Label();
            displayNamePromptLabel = new Label();
            displayNumberLabel = new Label();
            displayNumberPromptLabel = new Label();
            compareToLabel = new Label();
            compareToTextBox = new TextBox();
            greaterThanButton = new Button();
            lessThanButton = new Button();
            compareResultLabel = new Label();
            enterGroupBox.SuspendLayout();
            displayGroupBox.SuspendLayout();
            SuspendLayout();
            // 
            // enterGroupBox
            // 
            enterGroupBox.Controls.Add(monthNameTextBox);
            enterGroupBox.Controls.Add(monthNameLabel);
            enterGroupBox.Controls.Add(monthNumberTextBox);
            enterGroupBox.Controls.Add(monthNumberLabel);
            enterGroupBox.Location = new Point(12, 12);
            enterGroupBox.Name = "enterGroupBox";
            enterGroupBox.Size = new Size(337, 158);
            enterGroupBox.TabIndex = 0;
            enterGroupBox.TabStop = false;
            enterGroupBox.Text = "Enter Month Info";
            // 
            // monthNameTextBox
            // 
            monthNameTextBox.Location = new Point(138, 86);
            monthNameTextBox.Name = "monthNameTextBox";
            monthNameTextBox.Size = new Size(100, 23);
            monthNameTextBox.TabIndex = 3;
            // 
            // monthNameLabel
            // 
            monthNameLabel.AutoSize = true;
            monthNameLabel.Location = new Point(29, 89);
            monthNameLabel.Name = "monthNameLabel";
            monthNameLabel.Size = new Size(81, 15);
            monthNameLabel.TabIndex = 2;
            monthNameLabel.Text = "Month Name:";
            // 
            // monthNumberTextBox
            // 
            monthNumberTextBox.Location = new Point(137, 29);
            monthNumberTextBox.Name = "monthNumberTextBox";
            monthNumberTextBox.Size = new Size(100, 23);
            monthNumberTextBox.TabIndex = 1;
            // 
            // monthNumberLabel
            // 
            monthNumberLabel.AutoSize = true;
            monthNumberLabel.Location = new Point(21, 36);
            monthNumberLabel.Name = "monthNumberLabel";
            monthNumberLabel.Size = new Size(93, 15);
            monthNumberLabel.TabIndex = 0;
            monthNumberLabel.Text = "Month Number:";
            // 
            // createByNumberButton
            // 
            createByNumberButton.Location = new Point(12, 176);
            createByNumberButton.Name = "createByNumberButton";
            createByNumberButton.Size = new Size(114, 23);
            createByNumberButton.TabIndex = 1;
            createByNumberButton.Text = "Create by Number";
            createByNumberButton.UseVisualStyleBackColor = true;
            createByNumberButton.Click += createByNumberButton_Click;
            // 
            // createByNameButton
            // 
            createByNameButton.Location = new Point(227, 176);
            createByNameButton.Name = "createByNameButton";
            createByNameButton.Size = new Size(122, 23);
            createByNameButton.TabIndex = 2;
            createByNameButton.Text = "Create by Name";
            createByNameButton.UseVisualStyleBackColor = true;
            // 
            // useDefaultButton
            // 
            useDefaultButton.Location = new Point(12, 205);
            useDefaultButton.Name = "useDefaultButton";
            useDefaultButton.Size = new Size(114, 39);
            useDefaultButton.TabIndex = 3;
            useDefaultButton.Text = "Use Default Constructor";
            useDefaultButton.UseVisualStyleBackColor = true;
            // 
            // copyButton
            // 
            copyButton.Location = new Point(227, 205);
            copyButton.Name = "copyButton";
            copyButton.Size = new Size(122, 39);
            copyButton.TabIndex = 4;
            copyButton.Text = "Copy Current Month";
            copyButton.UseVisualStyleBackColor = true;
            // 
            // displayGroupBox
            // 
            displayGroupBox.Controls.Add(toStringLabel);
            displayGroupBox.Controls.Add(toStringPromptLabel);
            displayGroupBox.Controls.Add(displayNameLabel);
            displayGroupBox.Controls.Add(displayNamePromptLabel);
            displayGroupBox.Controls.Add(displayNumberLabel);
            displayGroupBox.Controls.Add(displayNumberPromptLabel);
            displayGroupBox.Location = new Point(417, 19);
            displayGroupBox.Name = "displayGroupBox";
            displayGroupBox.Size = new Size(354, 151);
            displayGroupBox.TabIndex = 5;
            displayGroupBox.TabStop = false;
            displayGroupBox.Text = "Month Info";
            // 
            // toStringLabel
            // 
            toStringLabel.BorderStyle = BorderStyle.FixedSingle;
            toStringLabel.Location = new Point(139, 101);
            toStringLabel.Name = "toStringLabel";
            toStringLabel.Size = new Size(100, 23);
            toStringLabel.TabIndex = 5;
            toStringLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // toStringPromptLabel
            // 
            toStringPromptLabel.AutoSize = true;
            toStringPromptLabel.Location = new Point(18, 101);
            toStringPromptLabel.Name = "toStringPromptLabel";
            toStringPromptLabel.Size = new Size(62, 15);
            toStringPromptLabel.TabIndex = 4;
            toStringPromptLabel.Text = "ToString():";
            // 
            // displayNameLabel
            // 
            displayNameLabel.BorderStyle = BorderStyle.FixedSingle;
            displayNameLabel.Location = new Point(139, 56);
            displayNameLabel.Name = "displayNameLabel";
            displayNameLabel.Size = new Size(100, 23);
            displayNameLabel.TabIndex = 3;
            displayNameLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // displayNamePromptLabel
            // 
            displayNamePromptLabel.AutoSize = true;
            displayNamePromptLabel.Location = new Point(18, 66);
            displayNamePromptLabel.Name = "displayNamePromptLabel";
            displayNamePromptLabel.Size = new Size(81, 15);
            displayNamePromptLabel.TabIndex = 2;
            displayNamePromptLabel.Text = "Month Name:";
            // 
            // displayNumberLabel
            // 
            displayNumberLabel.BorderStyle = BorderStyle.FixedSingle;
            displayNumberLabel.Location = new Point(139, 21);
            displayNumberLabel.Name = "displayNumberLabel";
            displayNumberLabel.Size = new Size(100, 23);
            displayNumberLabel.TabIndex = 1;
            displayNumberLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // displayNumberPromptLabel
            // 
            displayNumberPromptLabel.AutoSize = true;
            displayNumberPromptLabel.Location = new Point(18, 24);
            displayNumberPromptLabel.Name = "displayNumberPromptLabel";
            displayNumberPromptLabel.Size = new Size(93, 15);
            displayNumberPromptLabel.TabIndex = 0;
            displayNumberPromptLabel.Text = "Month Number:";
            // 
            // compareToLabel
            // 
            compareToLabel.AutoSize = true;
            compareToLabel.Location = new Point(417, 184);
            compareToLabel.Name = "compareToLabel";
            compareToLabel.Size = new Size(161, 15);
            compareToLabel.TabIndex = 6;
            compareToLabel.Text = "Compare To Month Number:";
            // 
            // compareToTextBox
            // 
            compareToTextBox.Location = new Point(604, 183);
            compareToTextBox.Name = "compareToTextBox";
            compareToTextBox.Size = new Size(100, 23);
            compareToTextBox.TabIndex = 7;
            // 
            // greaterThanButton
            // 
            greaterThanButton.Location = new Point(422, 221);
            greaterThanButton.Name = "greaterThanButton";
            greaterThanButton.Size = new Size(106, 23);
            greaterThanButton.TabIndex = 8;
            greaterThanButton.Text = "Is Greater Than?";
            greaterThanButton.UseVisualStyleBackColor = true;
            // 
            // lessThanButton
            // 
            lessThanButton.Location = new Point(604, 221);
            lessThanButton.Name = "lessThanButton";
            lessThanButton.Size = new Size(100, 23);
            lessThanButton.TabIndex = 9;
            lessThanButton.Text = "Is Less Than?";
            lessThanButton.UseVisualStyleBackColor = true;
            // 
            // compareResultLabel
            // 
            compareResultLabel.BorderStyle = BorderStyle.FixedSingle;
            compareResultLabel.Location = new Point(428, 260);
            compareResultLabel.Name = "compareResultLabel";
            compareResultLabel.Size = new Size(276, 23);
            compareResultLabel.TabIndex = 10;
            compareResultLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(compareResultLabel);
            Controls.Add(lessThanButton);
            Controls.Add(greaterThanButton);
            Controls.Add(compareToTextBox);
            Controls.Add(compareToLabel);
            Controls.Add(displayGroupBox);
            Controls.Add(copyButton);
            Controls.Add(useDefaultButton);
            Controls.Add(createByNameButton);
            Controls.Add(createByNumberButton);
            Controls.Add(enterGroupBox);
            Name = "Form1";
            Text = "Month Class Demo";
            enterGroupBox.ResumeLayout(false);
            enterGroupBox.PerformLayout();
            displayGroupBox.ResumeLayout(false);
            displayGroupBox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox enterGroupBox;
        private TextBox monthNumberTextBox;
        private Label monthNumberLabel;
        private TextBox monthNameTextBox;
        private Label monthNameLabel;
        private Button createByNumberButton;
        private Button createByNameButton;
        private Button useDefaultButton;
        private Button copyButton;
        private GroupBox displayGroupBox;
        private Label displayNumberLabel;
        private Label displayNumberPromptLabel;
        private Label displayNameLabel;
        private Label displayNamePromptLabel;
        private Label toStringLabel;
        private Label toStringPromptLabel;
        private Label compareToLabel;
        private TextBox compareToTextBox;
        private Button greaterThanButton;
        private Button lessThanButton;
        private Label compareResultLabel;
    }
}
