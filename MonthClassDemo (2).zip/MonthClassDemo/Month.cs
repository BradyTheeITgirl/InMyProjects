﻿using System;

namespace MonthClassDemo
{
    internal class Month
    {
        private int _monthNumber;

        public int MonthNumber
        {
            get { return _monthNumber; }
            set
            {
                if (value >= 1 && value <= 12)
                    _monthNumber = value;
                else
                    _monthNumber = 1;
            }
        }

        public string MonthName
        {
            get
            {
                switch (_monthNumber)
                {
                    case 1:
                        return "January";
                    case 2:
                        return "February";
                    case 3:
                        return "March";
                    case 4:
                        return "April";
                    case 5:
                        return "May";
                    case 6:
                        return "June";
                    case 7:
                        return "July";
                    case 8:
                        return "August";
                    case 9:
                        return "September";
                    case 10:
                        return "October";
                    case 11:
                        return "November";
                    case 12:
                        return "December";
                    default:
                        return "January";
                }
            }
        }

        public Month()
        {
            _monthNumber = 1;
        }

        public Month(int monthNumber)
        {
            MonthNumber = monthNumber;
        }

        public Month(string monthName)
        {
            switch (monthName.Trim().ToLower())
            {
                case "january":
                    _monthNumber = 1;
                    break;
                case "february":
                    _monthNumber = 2;
                    break;
                case "march":
                    _monthNumber = 3;
                    break;
                case "april":
                    _monthNumber = 4;
                    break;
                case "may":
                    _monthNumber = 5;
                    break;
                case "june":
                    _monthNumber = 6;
                    break;
                case "july":
                    _monthNumber = 7;
                    break;
                case "august":
                    _monthNumber = 8;
                    break;
                case "september":
                    _monthNumber = 9;
                    break;
                case "october":
                    _monthNumber = 10;
                    break;
                case "november":
                    _monthNumber = 11;
                    break;
                case "december":
                    _monthNumber = 12;
                    break;
                default:
                    _monthNumber = 1;
                    break;
            }
        }

        public Month(Month otherMonth)
        {
            _monthNumber = otherMonth.MonthNumber;
        }

        public bool GreaterThan(Month otherMonth)
        {
            return this.MonthNumber > otherMonth.MonthNumber;
        }

        public bool LessThan(Month otherMonth)
        {
            return this.MonthNumber < otherMonth.MonthNumber;
        }

        public override string ToString()
        {
            return MonthName;
        }
    }
}