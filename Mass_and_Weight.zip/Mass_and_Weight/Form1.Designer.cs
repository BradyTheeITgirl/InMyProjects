﻿namespace Mass_and_Weight
{
    partial class Mass_and_Weight
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            massPromptLabel = new Label();
            massTextBox = new TextBox();
            weightPromptLabel = new Label();
            weightLabel = new Label();
            calculateButton = new Button();
            exitButton = new Button();
            SuspendLayout();
            // 
            // massPromptLabel
            // 
            massPromptLabel.AutoSize = true;
            massPromptLabel.Location = new Point(102, 36);
            massPromptLabel.Name = "massPromptLabel";
            massPromptLabel.Size = new Size(213, 15);
            massPromptLabel.TabIndex = 0;
            massPromptLabel.Text = "\"Enter an object's mass (in kilograms):\"";
            massPromptLabel.Click += label1_Click;
            // 
            // massTextBox
            // 
            massTextBox.Location = new Point(139, 54);
            massTextBox.Name = "massTextBox";
            massTextBox.Size = new Size(100, 23);
            massTextBox.TabIndex = 1;
            // 
            // weightPromptLabel
            // 
            weightPromptLabel.AutoSize = true;
            weightPromptLabel.Location = new Point(102, 90);
            weightPromptLabel.Name = "weightPromptLabel";
            weightPromptLabel.Size = new Size(207, 15);
            weightPromptLabel.TabIndex = 2;
            weightPromptLabel.Text = " \"The object's weight (in Newtons) is:\"";
            // 
            // weightLabel
            // 
            weightLabel.BorderStyle = BorderStyle.FixedSingle;
            weightLabel.Location = new Point(139, 117);
            weightLabel.Name = "weightLabel";
            weightLabel.Size = new Size(100, 23);
            weightLabel.TabIndex = 3;
            weightLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            calculateButton.Location = new Point(103, 170);
            calculateButton.Name = "calculateButton";
            calculateButton.Size = new Size(75, 40);
            calculateButton.TabIndex = 4;
            calculateButton.Text = "\"Calculate Weight\"";
            calculateButton.UseVisualStyleBackColor = true;
            calculateButton.Click += calculateButton_Click;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(213, 170);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(75, 42);
            exitButton.TabIndex = 5;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            exitButton.Click += exitButton_Click;
            // 
            // Mass_and_Weight
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(exitButton);
            Controls.Add(calculateButton);
            Controls.Add(weightLabel);
            Controls.Add(weightPromptLabel);
            Controls.Add(massTextBox);
            Controls.Add(massPromptLabel);
            Name = "Mass_and_Weight";
            Text = "Mass and Weight";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label massPromptLabel;
        private TextBox massTextBox;
        private Label weightPromptLabel;
        private Label weightLabel;
        private Button calculateButton;
        private Button exitButton;
    }
}
