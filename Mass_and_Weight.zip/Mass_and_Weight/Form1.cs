namespace Mass_and_Weight
{
    public partial class Mass_and_Weight : Form
    {
        public Mass_and_Weight()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double mass, weight;

            if (double.TryParse(massTextBox.Text, out mass))
            {
                weight = mass * 9.8;
                weightLabel.Text = weight.ToString("n2");

                if (weight > 1000)
                {
                    MessageBox.Show("The object is too heavy.");
                }
                else if (weight < 10)
                {
                    MessageBox.Show("The object is too light.");
                }
            }
            else
            {
                MessageBox.Show("Invalid value for mass.");
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
