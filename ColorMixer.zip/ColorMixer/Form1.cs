namespace ColorMixer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load_1(object sender, EventArgs e)
        {

        }

        private void mixButton_Click(object sender, EventArgs e)
        {
            Color color1 = Color.White;
            if (radioRed1.Checked)
            {
                color1 = Color.Red;
            }
            else if (radioBlue1.Checked)
            {
                color1 = Color.Blue;
            }
            else if (radioYellow1.Checked)
            {
                color1 = Color.Yellow;
            }

            Color color2 = Color.White;
            if (radioRed2.Checked)
            {
                color2 = Color.Red;
            }
            else if (radioBlue2.Checked)
            {
                color2 = Color.Blue;
            }
            else if (radioYellow2.Checked)
            {
                color2 = Color.Yellow;
            }

            if (color1 == color2)
            {
                this.BackColor = color1;
            }
            else
            {
                if ((color1 == Color.Red && color2 == Color.Blue) || (color1 == Color.Blue && color2 == Color.Red))
                {
                    this.BackColor = Color.Purple; // Red + Blue = Purple
                }
                else if ((color1 == Color.Red && color2 == Color.Yellow) || (color1 == Color.Yellow && color2 == Color.Red))
                {
                    this.BackColor = Color.Orange; // Red + Yellow = Orange
                }
                else if ((color1 == Color.Yellow && color2 == Color.Blue) || (color1 == Color.Blue && color2 == Color.Yellow))
                {
                    this.BackColor = Color.Green; // Blue + Yellow = Green
                }
                else
                {
                    this.BackColor = Color.White; // Default if no valid combination
                }
            }

        }
    }
}
