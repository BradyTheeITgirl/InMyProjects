﻿namespace ColorMixer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            radioRed1 = new RadioButton();
            radioBlue1 = new RadioButton();
            radioYellow1 = new RadioButton();
            radioRed2 = new RadioButton();
            radioBlue2 = new RadioButton();
            radioYellow2 = new RadioButton();
            groupBox1 = new GroupBox();
            groupBox2 = new GroupBox();
            mixButton = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // radioRed1
            // 
            radioRed1.AutoSize = true;
            radioRed1.Location = new Point(40, 22);
            radioRed1.Name = "radioRed1";
            radioRed1.Size = new Size(45, 19);
            radioRed1.TabIndex = 0;
            radioRed1.TabStop = true;
            radioRed1.Text = "Red";
            radioRed1.UseVisualStyleBackColor = true;
            // 
            // radioBlue1
            // 
            radioBlue1.AutoSize = true;
            radioBlue1.Location = new Point(40, 47);
            radioBlue1.Name = "radioBlue1";
            radioBlue1.Size = new Size(48, 19);
            radioBlue1.TabIndex = 1;
            radioBlue1.TabStop = true;
            radioBlue1.Text = "Blue";
            radioBlue1.UseVisualStyleBackColor = true;
            // 
            // radioYellow1
            // 
            radioYellow1.AutoSize = true;
            radioYellow1.Location = new Point(40, 72);
            radioYellow1.Name = "radioYellow1";
            radioYellow1.Size = new Size(59, 19);
            radioYellow1.TabIndex = 2;
            radioYellow1.TabStop = true;
            radioYellow1.Text = "Yellow";
            radioYellow1.UseVisualStyleBackColor = true;
            // 
            // radioRed2
            // 
            radioRed2.AutoSize = true;
            radioRed2.Location = new Point(45, 22);
            radioRed2.Name = "radioRed2";
            radioRed2.Size = new Size(45, 19);
            radioRed2.TabIndex = 3;
            radioRed2.TabStop = true;
            radioRed2.Text = "Red";
            radioRed2.UseVisualStyleBackColor = true;
            // 
            // radioBlue2
            // 
            radioBlue2.AutoSize = true;
            radioBlue2.Location = new Point(45, 47);
            radioBlue2.Name = "radioBlue2";
            radioBlue2.Size = new Size(48, 19);
            radioBlue2.TabIndex = 4;
            radioBlue2.TabStop = true;
            radioBlue2.Text = "Blue";
            radioBlue2.UseVisualStyleBackColor = true;
            // 
            // radioYellow2
            // 
            radioYellow2.AutoSize = true;
            radioYellow2.Location = new Point(45, 72);
            radioYellow2.Name = "radioYellow2";
            radioYellow2.Size = new Size(59, 19);
            radioYellow2.TabIndex = 5;
            radioYellow2.TabStop = true;
            radioYellow2.Text = "Yellow";
            radioYellow2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radioRed1);
            groupBox1.Controls.Add(radioBlue1);
            groupBox1.Controls.Add(radioYellow1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(200, 100);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Select the First Color";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(radioRed2);
            groupBox2.Controls.Add(radioBlue2);
            groupBox2.Controls.Add(radioYellow2);
            groupBox2.Location = new Point(235, 12);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(200, 100);
            groupBox2.TabIndex = 7;
            groupBox2.TabStop = false;
            groupBox2.Text = "Select the Second Color";
            // 
            // mixButton
            // 
            mixButton.Location = new Point(183, 118);
            mixButton.Name = "mixButton";
            mixButton.Size = new Size(75, 23);
            mixButton.TabIndex = 8;
            mixButton.Text = "Mix";
            mixButton.UseVisualStyleBackColor = true;
            mixButton.Click += mixButton_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(469, 169);
            Controls.Add(mixButton);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "Color Mixer";
            Load += Form1_Load_1;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private RadioButton radioRed1;
        private RadioButton radioBlue1;
        private RadioButton radioYellow1;
        private RadioButton radioRed2;
        private RadioButton radioBlue2;
        private RadioButton radioYellow2;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private Button mixButton;
    }
}