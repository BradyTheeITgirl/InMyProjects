﻿namespace RandomAdditionQuiz
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            instructionsLabel = new Label();
            problemLabel = new Label();
            answerTextBox = new TextBox();
            checkAnswerButton = new Button();
            exitButton = new Button();
            SuspendLayout();
            // 
            // instructionsLabel
            // 
            instructionsLabel.AutoSize = true;
            instructionsLabel.Location = new Point(71, 9);
            instructionsLabel.Name = "instructionsLabel";
            instructionsLabel.Size = new Size(232, 15);
            instructionsLabel.TabIndex = 0;
            instructionsLabel.Text = "Enter your answer and click Check Answer.";
            // 
            // problemLabel
            // 
            problemLabel.AutoSize = true;
            problemLabel.Font = new Font("Segoe UI", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            problemLabel.Location = new Point(142, 33);
            problemLabel.Name = "problemLabel";
            problemLabel.Size = new Size(114, 25);
            problemLabel.TabIndex = 1;
            problemLabel.Text = "??? + ??? = ?";
            // 
            // answerTextBox
            // 
            answerTextBox.Location = new Point(142, 61);
            answerTextBox.Name = "answerTextBox";
            answerTextBox.Size = new Size(100, 23);
            answerTextBox.TabIndex = 2;
            // 
            // checkAnswerButton
            // 
            checkAnswerButton.Location = new Point(153, 90);
            checkAnswerButton.Name = "checkAnswerButton";
            checkAnswerButton.Size = new Size(75, 40);
            checkAnswerButton.TabIndex = 3;
            checkAnswerButton.Text = "Check Answer";
            checkAnswerButton.UseVisualStyleBackColor = true;
            checkAnswerButton.Click += checkAnswerButton_Click;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(297, 176);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(75, 23);
            exitButton.TabIndex = 4;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(384, 211);
            Controls.Add(exitButton);
            Controls.Add(checkAnswerButton);
            Controls.Add(answerTextBox);
            Controls.Add(problemLabel);
            Controls.Add(instructionsLabel);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Random Addition Quiz";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label instructionsLabel;
        private Label problemLabel;
        private TextBox answerTextBox;
        private Button checkAnswerButton;
        private Button exitButton;
    }
}
