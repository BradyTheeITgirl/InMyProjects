﻿namespace RandomAdditionQuiz
{
    public partial class Form1 : Form
    {
        // ------------------------------------------------------------
        // Program: Random Addition Quiz (Addition Practice)
        // Purpose: Generates two random integers (100–500) and checks
        //          the user's answer with input validation.
        // ------------------------------------------------------------

        // Class-level variables so multiple event handlers can use them
        private int num1;
        private int num2;

        // Random object created once (best practice)
        private Random rand = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        // ------------------------------------------------------------
        // Form Load: Generate the first problem when the form opens
        // ------------------------------------------------------------
        private void Form1_Load(object sender, EventArgs e)
        {
            GenerateProblem();
        }

        // ------------------------------------------------------------
        // GenerateProblem: Creates two random integers and updates label
        // ------------------------------------------------------------
        private void GenerateProblem()
        {
            num1 = rand.Next(100, 501);  // 100–500 inclusive
            num2 = rand.Next(100, 501);

            problemLabel.Text = $"{num1} + {num2} = ?";
        }

        // ------------------------------------------------------------
        // Check Answer Button: Validate input and check correctness
        // ------------------------------------------------------------
        private void checkAnswerButton_Click(object sender, EventArgs e)
        {
            int userAnswer;

            // Calculate correct answer for the current problem
            int correctAnswer = num1 + num2;

            // Loop structure (UI-friendly): user clicks again after feedback
            while (true)
            {
                // Validate input (prevents crashes)
                if (!int.TryParse(answerTextBox.Text, out userAnswer))
                {
                    MessageBox.Show("Please enter a valid number.");
                    answerTextBox.Clear();
                    answerTextBox.Focus();
                    return; // allow user to try again
                }

                // Check correctness
                if (userAnswer != correctAnswer)
                {
                    MessageBox.Show("Incorrect. Please try again.");
                    answerTextBox.SelectAll();
                    answerTextBox.Focus();
                    return; // allow user to try again
                }

                // If correct, exit loop
                MessageBox.Show("Correct!");
                break;
            }

            // Create a new problem and reset input
            GenerateProblem();
            answerTextBox.Clear();
            answerTextBox.Focus();
        }

        // ------------------------------------------------------------
        // Exit Button: Close the form
        // ------------------------------------------------------------
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}