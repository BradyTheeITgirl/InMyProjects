﻿namespace EmployeeClasses
{
    internal class ProductionWorker : Employee
    {
        public int ShiftNumber { get; set; }
        public decimal HourlyPayRate { get; set; }

        public ProductionWorker(string name, int number, int shiftNumber, decimal hourlyPayRate)
            : base(name, number)
        {
            ShiftNumber = shiftNumber;
            HourlyPayRate = hourlyPayRate;
        }

        public override string ToString()
        {
            string shiftName = ShiftNumber == 1 ? "Day" : "Night";

            return base.ToString() + "\n" +
                   $"Shift: {shiftName} ({ShiftNumber})\n" +
                   $"Hourly Pay Rate: {HourlyPayRate:C}";
        }
    }
}