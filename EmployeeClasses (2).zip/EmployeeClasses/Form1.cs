using System;
using System.Windows.Forms;

namespace EmployeeClasses
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            string name = nameTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Please enter the employee's name.");
                return;
            }

            if (!int.TryParse(numberTextBox.Text, out int number))
            {
                MessageBox.Show("Please enter a valid employee number.");
                return;
            }

            if (!decimal.TryParse(payTextBox.Text, out decimal payRate))
            {
                MessageBox.Show("Please enter a valid hourly pay rate.");
                return;
            }

            int shiftNum;

            if (dayRadioButton.Checked)
            {
                shiftNum = 1;
            }
            else if (nightRadioButton.Checked)
            {
                shiftNum = 2;
            }
            else
            {
                MessageBox.Show("Please select a shift.");
                return;
            }

            ProductionWorker worker = new ProductionWorker(name, number, shiftNum, payRate);

            outputLabel.Text = worker.ToString();
        }
    }
}
