﻿namespace EmployeeClasses
{
    internal class Employee
    {
        public string Name { get; set; }
        public int Number { get; set; }

        public Employee(string name, int number)
        {
            Name = name;
            Number = number;
        }

        public override string ToString()
        {
            return $"Employee Name: {Name}\n" +
                   $"Employee Number: {Number}";
        }
    }
}