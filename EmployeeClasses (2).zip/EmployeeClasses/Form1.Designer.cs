﻿namespace EmployeeClasses
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            nameLabel = new Label();
            nameTextBox = new TextBox();
            numberLabel = new Label();
            numberTextBox = new TextBox();
            shiftGroupBox = new GroupBox();
            displayButton = new Button();
            payTextBox = new TextBox();
            payLabel = new Label();
            nightRadioButton = new RadioButton();
            dayRadioButton = new RadioButton();
            outputLabel = new Label();
            shiftGroupBox.SuspendLayout();
            SuspendLayout();
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new Point(61, 9);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(97, 15);
            nameLabel.TabIndex = 0;
            nameLabel.Text = "Employee Name:";
            // 
            // nameTextBox
            // 
            nameTextBox.Location = new Point(164, 1);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.Size = new Size(100, 23);
            nameTextBox.TabIndex = 1;
            // 
            // numberLabel
            // 
            numberLabel.AutoSize = true;
            numberLabel.Location = new Point(49, 39);
            numberLabel.Name = "numberLabel";
            numberLabel.Size = new Size(109, 15);
            numberLabel.TabIndex = 2;
            numberLabel.Text = "Employee Number:";
            numberLabel.Click += label1_Click;
            // 
            // numberTextBox
            // 
            numberTextBox.Location = new Point(164, 39);
            numberTextBox.Name = "numberTextBox";
            numberTextBox.Size = new Size(100, 23);
            numberTextBox.TabIndex = 3;
            // 
            // shiftGroupBox
            // 
            shiftGroupBox.Controls.Add(displayButton);
            shiftGroupBox.Controls.Add(payTextBox);
            shiftGroupBox.Controls.Add(payLabel);
            shiftGroupBox.Controls.Add(nightRadioButton);
            shiftGroupBox.Controls.Add(dayRadioButton);
            shiftGroupBox.Location = new Point(49, 68);
            shiftGroupBox.Name = "shiftGroupBox";
            shiftGroupBox.Size = new Size(237, 158);
            shiftGroupBox.TabIndex = 4;
            shiftGroupBox.TabStop = false;
            shiftGroupBox.Text = "Shift Number";
            // 
            // displayButton
            // 
            displayButton.Location = new Point(18, 125);
            displayButton.Name = "displayButton";
            displayButton.Size = new Size(75, 23);
            displayButton.TabIndex = 4;
            displayButton.Text = "Display";
            displayButton.UseVisualStyleBackColor = true;
            displayButton.Click += displayButton_Click;
            // 
            // payTextBox
            // 
            payTextBox.Location = new Point(127, 88);
            payTextBox.Name = "payTextBox";
            payTextBox.Size = new Size(100, 23);
            payTextBox.TabIndex = 3;
            // 
            // payLabel
            // 
            payLabel.AutoSize = true;
            payLabel.Location = new Point(18, 96);
            payLabel.Name = "payLabel";
            payLabel.Size = new Size(103, 15);
            payLabel.TabIndex = 2;
            payLabel.Text = "Hourly Pay Rate: $";
            // 
            // nightRadioButton
            // 
            nightRadioButton.AutoSize = true;
            nightRadioButton.Location = new Point(19, 64);
            nightRadioButton.Name = "nightRadioButton";
            nightRadioButton.Size = new Size(72, 19);
            nightRadioButton.TabIndex = 1;
            nightRadioButton.TabStop = true;
            nightRadioButton.Text = "Night (2)";
            nightRadioButton.UseVisualStyleBackColor = true;
            // 
            // dayRadioButton
            // 
            dayRadioButton.AutoSize = true;
            dayRadioButton.Location = new Point(22, 27);
            dayRadioButton.Name = "dayRadioButton";
            dayRadioButton.Size = new Size(62, 19);
            dayRadioButton.TabIndex = 0;
            dayRadioButton.TabStop = true;
            dayRadioButton.Text = "Day (1)";
            dayRadioButton.UseVisualStyleBackColor = true;
            // 
            // outputLabel
            // 
            outputLabel.BorderStyle = BorderStyle.FixedSingle;
            outputLabel.Location = new Point(75, 238);
            outputLabel.Name = "outputLabel";
            outputLabel.Size = new Size(100, 23);
            outputLabel.TabIndex = 5;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(outputLabel);
            Controls.Add(shiftGroupBox);
            Controls.Add(numberTextBox);
            Controls.Add(numberLabel);
            Controls.Add(nameTextBox);
            Controls.Add(nameLabel);
            Name = "Form1";
            Text = "Employee Classes";
            shiftGroupBox.ResumeLayout(false);
            shiftGroupBox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label nameLabel;
        private TextBox nameTextBox;
        private Label numberLabel;
        private TextBox numberTextBox;
        private GroupBox shiftGroupBox;
        private RadioButton nightRadioButton;
        private RadioButton dayRadioButton;
        private Button displayButton;
        private TextBox payTextBox;
        private Label payLabel;
        private Label outputLabel;
    }
}
