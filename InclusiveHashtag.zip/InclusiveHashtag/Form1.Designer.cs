﻿namespace InclusiveHashtag
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            instructionLabel = new Label();
            inputTextBox = new TextBox();
            generateButton = new Button();
            resultLabel = new Label();
            SuspendLayout();
            // 
            // instructionLabel
            // 
            instructionLabel.AutoSize = true;
            instructionLabel.Location = new Point(294, 47);
            instructionLabel.Name = "instructionLabel";
            instructionLabel.Size = new Size(265, 15);
            instructionLabel.TabIndex = 0;
            instructionLabel.Text = "Enter a phrase to convert to an inclusive hashtag:";
            // 
            // inputTextBox
            // 
            inputTextBox.Location = new Point(381, 65);
            inputTextBox.Name = "inputTextBox";
            inputTextBox.Size = new Size(100, 23);
            inputTextBox.TabIndex = 1;
            // 
            // generateButton
            // 
            generateButton.Location = new Point(381, 104);
            generateButton.Name = "generateButton";
            generateButton.Size = new Size(97, 41);
            generateButton.TabIndex = 2;
            generateButton.Text = "Generate Hashtag";
            generateButton.UseVisualStyleBackColor = true;
            generateButton.Click += generateButton_Click;
            // 
            // resultLabel
            // 
            resultLabel.AutoSize = true;
            resultLabel.Location = new Point(396, 158);
            resultLabel.Name = "resultLabel";
            resultLabel.Size = new Size(38, 15);
            resultLabel.TabIndex = 3;
            resultLabel.Text = "label1";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(resultLabel);
            Controls.Add(generateButton);
            Controls.Add(inputTextBox);
            Controls.Add(instructionLabel);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label instructionLabel;
        private TextBox inputTextBox;
        private Button generateButton;
        private Label resultLabel;
    }
}
