namespace InclusiveHashtag
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private string CreateInclusiveHashtag(string sentence)
        {
            string[] words = sentence.Split(' ');
            string hashtag = "#";

            foreach (string word in words)
            {
                if (!string.IsNullOrWhiteSpace(word))
                {
                    string formattedWord =
                        char.ToUpper(word[0]) + word.Substring(1).ToLower();

                    hashtag += formattedWord;
                }
            }

            return hashtag;
        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text.Trim();

            if (string.IsNullOrEmpty(input))
            {
                MessageBox.Show("Please enter a phrase.");
                return;
            }

            string hashtag = CreateInclusiveHashtag(input);

            resultLabel.Text = hashtag;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
