﻿using System;                     // Provides access to Console.ReadLine, Console.WriteLine, etc.
using System.Collections.Generic; // Allows use of List<T> to store missed question indexes

const int NUM_QUESTIONS = 10;
int[] firstFactor = new int[NUM_QUESTIONS];
int[] secondFactor = new int[NUM_QUESTIONS];
int[] correctAnswers = new int[NUM_QUESTIONS];
int[] userAnswers = new int[NUM_QUESTIONS];
List<int> missedQuestions = new List<int>();
Random rand = new Random();

// Ask the original 10 multiplication questions
for (int i = 0; i < NUM_QUESTIONS; i++)
{
    firstFactor[i] = rand.Next(1, 16);  // 1 to 15
    secondFactor[i] = rand.Next(1, 16);
    correctAnswers[i] = firstFactor[i] * secondFactor[i];

    int userInput;
    bool validInput = false;

    while (!validInput)
    {
        Console.Write($"Problem {i + 1}: What is {firstFactor[i]} x {secondFactor[i]}? ");
        string input = Console.ReadLine();

        if (int.TryParse(input, out userInput))
        {
            validInput = true;
            userAnswers[i] = userInput;

            if (userAnswers[i] != correctAnswers[i])
            {
                missedQuestions.Add(i);
            }
        }
        else
        {
            Console.WriteLine("Please enter a whole number.");
        }
    }
}

// Display score
int correctCount = NUM_QUESTIONS - missedQuestions.Count;
Console.WriteLine($"\nYou got {correctCount} out of {NUM_QUESTIONS} correct.");

// Retry missed questions
if (missedQuestions.Count > 0)
{
    Console.WriteLine("\nLet's try the ones you missed again.");

    foreach (int i in missedQuestions)
    {
        int retryAnswer;
        bool validInput = false;

        while (!validInput)
        {
            Console.Write($"Retry Problem {i + 1}: What is {firstFactor[i]} x {secondFactor[i]}? ");
            string input = Console.ReadLine();

            if (int.TryParse(input, out retryAnswer))
            {
                validInput = true;

                if (retryAnswer == correctAnswers[i])
                {
                    Console.WriteLine("Correct!");
                }
                else
                {
                    Console.WriteLine($"Incorrect. The correct answer is {correctAnswers[i]}.");
                }
            }
            else
            {
                Console.WriteLine("Please enter a whole number.");
            }
        }
    }
}
else
{
    Console.WriteLine("Perfect score! Great job!");
}

// Exit prompt
Console.WriteLine("\nPress any key to exit.");
Console.ReadKey();