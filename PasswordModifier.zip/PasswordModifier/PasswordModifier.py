# PasswordModifier.py
# This program strengthens a simple password by replacing
# specific characters and appending "!" to the end.

# Get user input
password = input()

# Replace characters according to the key
password = password.replace('i', '1')
password = password.replace('a', '@')
password = password.replace('m', 'M')
password = password.replace('B', '8')
password = password.replace('s', '$')

# Append "!" to the end
password += '!'

# Display the modified password
print(password)

