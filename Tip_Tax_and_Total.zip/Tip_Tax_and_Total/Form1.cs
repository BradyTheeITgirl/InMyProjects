namespace Tip_Tax_and_Total
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Calculate Button Click Event
        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Declare variables
            decimal foodCharge, tip, tax, total;

            // Get user input
            foodCharge = decimal.Parse(foodChargeTextBox.Text);

            // Perform calculations
            tip = foodCharge * 0.15m;
            tax = foodCharge * 0.07m;
            total = foodCharge + tip + tax;

            // Display results
            tipLabel.Text = tip.ToString("C");
            taxLabel.Text = tax.ToString("C");
            totalLabel.Text = total.ToString("C");
        }

        // Exit Button Click Event
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

