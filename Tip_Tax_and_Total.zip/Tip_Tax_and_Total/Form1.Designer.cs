﻿namespace Tip_Tax_and_Total
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            foodChargePromptLabel = new Label();
            foodChargeTextBox = new TextBox();
            tipPromptLabel = new Label();
            taxPromptLabel = new Label();
            totalPromptLabel = new Label();
            calculateButton = new Button();
            exitButton = new Button();
            tipLabel = new Label();
            taxLabel = new Label();
            totalLabel = new Label();
            SuspendLayout();
            // 
            // foodChargePromptLabel
            // 
            foodChargePromptLabel.AutoSize = true;
            foodChargePromptLabel.Location = new Point(156, 67);
            foodChargePromptLabel.Name = "foodChargePromptLabel";
            foodChargePromptLabel.Size = new Size(124, 15);
            foodChargePromptLabel.TabIndex = 0;
            foodChargePromptLabel.Text = "Enter the food charge:";
            foodChargePromptLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // foodChargeTextBox
            // 
            foodChargeTextBox.Location = new Point(286, 67);
            foodChargeTextBox.Name = "foodChargeTextBox";
            foodChargeTextBox.Size = new Size(100, 23);
            foodChargeTextBox.TabIndex = 1;
            // 
            // tipPromptLabel
            // 
            tipPromptLabel.BorderStyle = BorderStyle.FixedSingle;
            tipPromptLabel.Location = new Point(156, 105);
            tipPromptLabel.Name = "tipPromptLabel";
            tipPromptLabel.Size = new Size(100, 23);
            tipPromptLabel.TabIndex = 2;
            tipPromptLabel.Text = "Tip(15%)";
            tipPromptLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // taxPromptLabel
            // 
            taxPromptLabel.BorderStyle = BorderStyle.FixedSingle;
            taxPromptLabel.Location = new Point(156, 140);
            taxPromptLabel.Name = "taxPromptLabel";
            taxPromptLabel.Size = new Size(100, 23);
            taxPromptLabel.TabIndex = 4;
            taxPromptLabel.Text = "Tax (7%)";
            taxPromptLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // totalPromptLabel
            // 
            totalPromptLabel.BorderStyle = BorderStyle.FixedSingle;
            totalPromptLabel.Location = new Point(156, 173);
            totalPromptLabel.Name = "totalPromptLabel";
            totalPromptLabel.Size = new Size(100, 23);
            totalPromptLabel.TabIndex = 6;
            totalPromptLabel.Text = "Total";
            totalPromptLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // calculateButton
            // 
            calculateButton.Location = new Point(181, 230);
            calculateButton.Name = "calculateButton";
            calculateButton.Size = new Size(75, 44);
            calculateButton.TabIndex = 8;
            calculateButton.Text = "Calculate Total";
            calculateButton.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(286, 230);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(75, 42);
            exitButton.TabIndex = 9;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            // 
            // tipLabel
            // 
            tipLabel.BorderStyle = BorderStyle.FixedSingle;
            tipLabel.Location = new Point(286, 105);
            tipLabel.Name = "tipLabel";
            tipLabel.Size = new Size(100, 23);
            tipLabel.TabIndex = 10;
            tipLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // taxLabel
            // 
            taxLabel.BorderStyle = BorderStyle.FixedSingle;
            taxLabel.Location = new Point(286, 148);
            taxLabel.Name = "taxLabel";
            taxLabel.Size = new Size(100, 23);
            taxLabel.TabIndex = 11;
            // 
            // totalLabel
            // 
            totalLabel.BorderStyle = BorderStyle.FixedSingle;
            totalLabel.Location = new Point(286, 177);
            totalLabel.Name = "totalLabel";
            totalLabel.Size = new Size(100, 23);
            totalLabel.TabIndex = 12;
            totalLabel.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(totalLabel);
            Controls.Add(taxLabel);
            Controls.Add(tipLabel);
            Controls.Add(exitButton);
            Controls.Add(calculateButton);
            Controls.Add(totalPromptLabel);
            Controls.Add(taxPromptLabel);
            Controls.Add(tipPromptLabel);
            Controls.Add(foodChargeTextBox);
            Controls.Add(foodChargePromptLabel);
            Name = "Form1";
            Text = "Tip, Tax, and Total";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label foodChargePromptLabel;
        private TextBox foodChargeTextBox;
        private Label tipPromptLabel;
        private Label taxPromptLabel;
        private Label totalPromptLabel;
        private Button calculateButton;
        private Button exitButton;
        private Label tipLabel;
        private Label taxLabel;
        private Label totalLabel;
    }
}
