﻿namespace OrionConstellation
{
    partial class OrionConstellation
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OrionConstellation));
            orionPictureBox = new PictureBox();
            betelgeuseLabel = new Label();
            meissaLabel = new Label();
            alnitakLabel = new Label();
            alnilamLabel = new Label();
            mintakaLabel = new Label();
            saiphLabel = new Label();
            rigelLabel = new Label();
            showButton = new Button();
            hideButton = new Button();
            exitButton = new Button();
            ((System.ComponentModel.ISupportInitialize)orionPictureBox).BeginInit();
            SuspendLayout();
            // 
            // orionPictureBox
            // 
            orionPictureBox.Image = (Image)resources.GetObject("orionPictureBox.Image");
            orionPictureBox.Location = new Point(130, 12);
            orionPictureBox.Name = "orionPictureBox";
            orionPictureBox.Size = new Size(400, 472);
            orionPictureBox.TabIndex = 0;
            orionPictureBox.TabStop = false;
            // 
            // betelgeuseLabel
            // 
            betelgeuseLabel.AutoSize = true;
            betelgeuseLabel.Location = new Point(189, 45);
            betelgeuseLabel.Name = "betelgeuseLabel";
            betelgeuseLabel.Size = new Size(64, 15);
            betelgeuseLabel.TabIndex = 1;
            betelgeuseLabel.Text = "Betelgeuse";
            betelgeuseLabel.Visible = false;
            // 
            // meissaLabel
            // 
            meissaLabel.AutoSize = true;
            meissaLabel.Location = new Point(387, 88);
            meissaLabel.Name = "meissaLabel";
            meissaLabel.Size = new Size(43, 15);
            meissaLabel.TabIndex = 2;
            meissaLabel.Text = "Meissa";
            meissaLabel.Visible = false;
            // 
            // alnitakLabel
            // 
            alnitakLabel.AutoSize = true;
            alnitakLabel.Location = new Point(224, 236);
            alnitakLabel.Name = "alnitakLabel";
            alnitakLabel.Size = new Size(44, 15);
            alnitakLabel.TabIndex = 3;
            alnitakLabel.Text = "Alnitak";
            alnitakLabel.Visible = false;
            // 
            // alnilamLabel
            // 
            alnilamLabel.AutoSize = true;
            alnilamLabel.Location = new Point(267, 221);
            alnilamLabel.Name = "alnilamLabel";
            alnilamLabel.Size = new Size(48, 15);
            alnilamLabel.TabIndex = 4;
            alnilamLabel.Text = "Alnilam";
            alnilamLabel.Visible = false;
            // 
            // mintakaLabel
            // 
            mintakaLabel.AutoSize = true;
            mintakaLabel.Location = new Point(333, 205);
            mintakaLabel.Name = "mintakaLabel";
            mintakaLabel.Size = new Size(50, 15);
            mintakaLabel.TabIndex = 5;
            mintakaLabel.Text = "Mintaka";
            mintakaLabel.Visible = false;
            // 
            // saiphLabel
            // 
            saiphLabel.AutoSize = true;
            saiphLabel.Location = new Point(198, 397);
            saiphLabel.Name = "saiphLabel";
            saiphLabel.Size = new Size(36, 15);
            saiphLabel.TabIndex = 6;
            saiphLabel.Text = "Saiph";
            saiphLabel.Visible = false;
            // 
            // rigelLabel
            // 
            rigelLabel.AutoSize = true;
            rigelLabel.Location = new Point(392, 359);
            rigelLabel.Name = "rigelLabel";
            rigelLabel.Size = new Size(33, 15);
            rigelLabel.TabIndex = 7;
            rigelLabel.Text = "Rigel";
            rigelLabel.Visible = false;
            // 
            // showButton
            // 
            showButton.Location = new Point(198, 499);
            showButton.Name = "showButton";
            showButton.Size = new Size(75, 38);
            showButton.TabIndex = 8;
            showButton.Text = "Show Star Names";
            showButton.UseVisualStyleBackColor = true;
            showButton.Click += showButton_Click;
            // 
            // hideButton
            // 
            hideButton.Location = new Point(308, 499);
            hideButton.Name = "hideButton";
            hideButton.Size = new Size(75, 38);
            hideButton.TabIndex = 9;
            hideButton.Text = "Hide Star Names";
            hideButton.UseVisualStyleBackColor = true;
            hideButton.Click += hideButton_Click;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(421, 499);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(75, 38);
            exitButton.TabIndex = 10;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            exitButton.Click += exitButton_Click;
            // 
            // OrionConstellation
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 558);
            Controls.Add(exitButton);
            Controls.Add(hideButton);
            Controls.Add(showButton);
            Controls.Add(rigelLabel);
            Controls.Add(saiphLabel);
            Controls.Add(mintakaLabel);
            Controls.Add(alnilamLabel);
            Controls.Add(alnitakLabel);
            Controls.Add(meissaLabel);
            Controls.Add(betelgeuseLabel);
            Controls.Add(orionPictureBox);
            Name = "OrionConstellation";
            Text = "Orion Constellation";
            ((System.ComponentModel.ISupportInitialize)orionPictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox orionPictureBox;
        private Label betelgeuseLabel;
        private Label meissaLabel;
        private Label alnitakLabel;
        private Label alnilamLabel;
        private Label mintakaLabel;
        private Label saiphLabel;
        private Label rigelLabel;
        private Button showButton;
        private Button hideButton;
        private Button exitButton;
    }
}
