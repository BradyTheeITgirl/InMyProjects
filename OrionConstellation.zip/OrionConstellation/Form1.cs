namespace OrionConstellation
{
    public partial class OrionConstellation : Form
    {
        public OrionConstellation()
        {
            InitializeComponent();
        }

        private void showButton_Click(object sender, EventArgs e)
        {
            betelgeuseLabel.Visible = true;
            meissaLabel.Visible = true;
            alnitakLabel.Visible = true;
            alnilamLabel.Visible = true;
            mintakaLabel.Visible = true;
            saiphLabel.Visible = true;
            rigelLabel.Visible = true;
        }

        private void hideButton_Click(object sender, EventArgs e)
        {
            betelgeuseLabel.Visible = false;
            meissaLabel.Visible = false;
            alnitakLabel.Visible = false;
            alnilamLabel.Visible = false;
            mintakaLabel.Visible = false;
            saiphLabel.Visible = false;
            rigelLabel.Visible = false;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
