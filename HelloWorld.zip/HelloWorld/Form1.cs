namespace HelloWorld
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void messageButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Hello World");
            displayLabel.Text = "Welcome to C#!";
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            displayLabel.Text = "You clicked the picture!";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
