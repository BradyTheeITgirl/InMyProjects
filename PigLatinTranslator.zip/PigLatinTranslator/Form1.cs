using System;
using System.Linq;
using System.Windows.Forms;

namespace PigLatinTranslator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void translateButton_Click(object sender, EventArgs e)
        {
            string input = inputTextBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(input))
            {
                MessageBox.Show("Please enter a phrase to translate.");
                inputTextBox.Focus();
                return;
            }

            resultLabel.Text = TranslateToPigLatin(input);
        }

        private string TranslateToPigLatin(string sentence)
        {
            string[] words = sentence.Split(' ');

            for (int i = 0; i < words.Length; i++)
            {
                string word = words[i];

                if (string.IsNullOrWhiteSpace(word))
                {
                    continue;
                }

                string lowerWord = word.ToLower();

                if (StartsWithVowel(lowerWord))
                {
                    words[i] = lowerWord + "way";
                }
                else
                {
                    int vowelIndex = FindFirstVowel(lowerWord);

                    if (vowelIndex == -1)
                    {
                        words[i] = lowerWord + "ay";
                    }
                    else
                    {
                        words[i] = lowerWord.Substring(vowelIndex) +
                                   "-" +
                                   lowerWord.Substring(0, vowelIndex) +
                                   "ay";
                    }
                }
            }

            return string.Join(" ", words);
        }

        private bool StartsWithVowel(string word)
        {
            return word.StartsWith("a") ||
                   word.StartsWith("e") ||
                   word.StartsWith("i") ||
                   word.StartsWith("o") ||
                   word.StartsWith("u");
        }

        private int FindFirstVowel(string word)
        {
            for (int i = 0; i < word.Length; i++)
            {
                char letter = word[i];

                if (letter == 'a' || letter == 'e' || letter == 'i' ||
                    letter == 'o' || letter == 'u')
                {
                    return i;
                }
            }

            return -1;
        }
    }
}
