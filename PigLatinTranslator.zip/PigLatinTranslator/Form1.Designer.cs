﻿namespace PigLatinTranslator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            instructionLabel = new Label();
            inputTextBox = new TextBox();
            translateButton = new Button();
            resultLabel = new Label();
            SuspendLayout();
            // 
            // instructionLabel
            // 
            instructionLabel.AutoSize = true;
            instructionLabel.Location = new Point(306, 44);
            instructionLabel.Name = "instructionLabel";
            instructionLabel.Size = new Size(219, 15);
            instructionLabel.TabIndex = 0;
            instructionLabel.Text = "Enter a phrase to translate into Pig Latin:";
            // 
            // inputTextBox
            // 
            inputTextBox.Location = new Point(354, 71);
            inputTextBox.Name = "inputTextBox";
            inputTextBox.Size = new Size(100, 23);
            inputTextBox.TabIndex = 1;
            // 
            // translateButton
            // 
            translateButton.Location = new Point(359, 119);
            translateButton.Name = "translateButton";
            translateButton.Size = new Size(75, 23);
            translateButton.TabIndex = 2;
            translateButton.Text = "Translate";
            translateButton.UseVisualStyleBackColor = true;
            // 
            // resultLabel
            // 
            resultLabel.AutoSize = true;
            resultLabel.Location = new Point(351, 163);
            resultLabel.Name = "resultLabel";
            resultLabel.Size = new Size(0, 15);
            resultLabel.TabIndex = 3;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(resultLabel);
            Controls.Add(translateButton);
            Controls.Add(inputTextBox);
            Controls.Add(instructionLabel);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label instructionLabel;
        private TextBox inputTextBox;
        private Button translateButton;
        private Label resultLabel;
    }
}
