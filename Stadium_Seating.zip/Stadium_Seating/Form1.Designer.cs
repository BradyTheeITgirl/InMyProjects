﻿namespace Stadium_Seating
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            inputGroupBox = new GroupBox();
            outputGroupBox = new GroupBox();
            instructionsLabel = new Label();
            classAPromptLabel = new Label();
            classBPromptLabel = new Label();
            classCPromptLabel = new Label();
            classARevenueLabel = new Label();
            classBRevenueLabel = new Label();
            classCRevenueLabel = new Label();
            totalRevenueLabel = new Label();
            classATextBox = new TextBox();
            classBTextBox = new TextBox();
            classCTextBox = new TextBox();
            classATotalLabel = new Label();
            classBTotalLabel = new Label();
            classCTotalLabel = new Label();
            totalLabel = new Label();
            calculateButton = new Button();
            clearButton = new Button();
            exitButton = new Button();
            inputGroupBox.SuspendLayout();
            outputGroupBox.SuspendLayout();
            SuspendLayout();
            // 
            // inputGroupBox
            // 
            inputGroupBox.Controls.Add(classCTextBox);
            inputGroupBox.Controls.Add(classBTextBox);
            inputGroupBox.Controls.Add(classATextBox);
            inputGroupBox.Controls.Add(classCPromptLabel);
            inputGroupBox.Controls.Add(classBPromptLabel);
            inputGroupBox.Controls.Add(classAPromptLabel);
            inputGroupBox.Controls.Add(instructionsLabel);
            inputGroupBox.Location = new Point(88, 38);
            inputGroupBox.Name = "inputGroupBox";
            inputGroupBox.Size = new Size(277, 288);
            inputGroupBox.TabIndex = 0;
            inputGroupBox.TabStop = false;
            inputGroupBox.Text = "Tickets Sold";
            // 
            // outputGroupBox
            // 
            outputGroupBox.Controls.Add(totalLabel);
            outputGroupBox.Controls.Add(classCTotalLabel);
            outputGroupBox.Controls.Add(classBTotalLabel);
            outputGroupBox.Controls.Add(classATotalLabel);
            outputGroupBox.Controls.Add(totalRevenueLabel);
            outputGroupBox.Controls.Add(classCRevenueLabel);
            outputGroupBox.Controls.Add(classBRevenueLabel);
            outputGroupBox.Controls.Add(classARevenueLabel);
            outputGroupBox.Location = new Point(371, 38);
            outputGroupBox.Name = "outputGroupBox";
            outputGroupBox.Size = new Size(266, 288);
            outputGroupBox.TabIndex = 1;
            outputGroupBox.TabStop = false;
            outputGroupBox.Text = "Revenue Generated";
            // 
            // instructionsLabel
            // 
            instructionsLabel.Location = new Point(6, 19);
            instructionsLabel.Name = "instructionsLabel";
            instructionsLabel.Size = new Size(265, 46);
            instructionsLabel.TabIndex = 0;
            instructionsLabel.Text = "Enter the number of tickets sold for each class of seats.";
            // 
            // classAPromptLabel
            // 
            classAPromptLabel.AutoSize = true;
            classAPromptLabel.Location = new Point(6, 65);
            classAPromptLabel.Name = "classAPromptLabel";
            classAPromptLabel.Size = new Size(48, 15);
            classAPromptLabel.TabIndex = 1;
            classAPromptLabel.Text = "Class A:";
            // 
            // classBPromptLabel
            // 
            classBPromptLabel.AutoSize = true;
            classBPromptLabel.Location = new Point(6, 113);
            classBPromptLabel.Name = "classBPromptLabel";
            classBPromptLabel.Size = new Size(47, 15);
            classBPromptLabel.TabIndex = 2;
            classBPromptLabel.Text = "Class B:";
            // 
            // classCPromptLabel
            // 
            classCPromptLabel.AutoSize = true;
            classCPromptLabel.Location = new Point(6, 162);
            classCPromptLabel.Name = "classCPromptLabel";
            classCPromptLabel.Size = new Size(48, 15);
            classCPromptLabel.TabIndex = 3;
            classCPromptLabel.Text = "Class C:";
            // 
            // classARevenueLabel
            // 
            classARevenueLabel.AutoSize = true;
            classARevenueLabel.Location = new Point(6, 65);
            classARevenueLabel.Name = "classARevenueLabel";
            classARevenueLabel.Size = new Size(48, 15);
            classARevenueLabel.TabIndex = 0;
            classARevenueLabel.Text = "Class A:";
            // 
            // classBRevenueLabel
            // 
            classBRevenueLabel.AutoSize = true;
            classBRevenueLabel.Location = new Point(6, 113);
            classBRevenueLabel.Name = "classBRevenueLabel";
            classBRevenueLabel.Size = new Size(47, 15);
            classBRevenueLabel.TabIndex = 1;
            classBRevenueLabel.Text = "Class B:";
            // 
            // classCRevenueLabel
            // 
            classCRevenueLabel.AutoSize = true;
            classCRevenueLabel.Location = new Point(6, 162);
            classCRevenueLabel.Name = "classCRevenueLabel";
            classCRevenueLabel.Size = new Size(48, 15);
            classCRevenueLabel.TabIndex = 2;
            classCRevenueLabel.Text = "Class C:";
            // 
            // totalRevenueLabel
            // 
            totalRevenueLabel.AutoSize = true;
            totalRevenueLabel.Location = new Point(6, 210);
            totalRevenueLabel.Name = "totalRevenueLabel";
            totalRevenueLabel.Size = new Size(35, 15);
            totalRevenueLabel.TabIndex = 3;
            totalRevenueLabel.Text = "Total:";
            // 
            // classATextBox
            // 
            classATextBox.Location = new Point(100, 62);
            classATextBox.Name = "classATextBox";
            classATextBox.Size = new Size(100, 23);
            classATextBox.TabIndex = 4;
            // 
            // classBTextBox
            // 
            classBTextBox.Location = new Point(100, 110);
            classBTextBox.Name = "classBTextBox";
            classBTextBox.Size = new Size(100, 23);
            classBTextBox.TabIndex = 5;
            // 
            // classCTextBox
            // 
            classCTextBox.Location = new Point(100, 159);
            classCTextBox.Name = "classCTextBox";
            classCTextBox.Size = new Size(100, 23);
            classCTextBox.TabIndex = 6;
            // 
            // classATotalLabel
            // 
            classATotalLabel.AllowDrop = true;
            classATotalLabel.BorderStyle = BorderStyle.FixedSingle;
            classATotalLabel.Location = new Point(89, 65);
            classATotalLabel.Name = "classATotalLabel";
            classATotalLabel.Size = new Size(100, 23);
            classATotalLabel.TabIndex = 4;
            classATotalLabel.TextAlign = ContentAlignment.MiddleRight;
            // 
            // classBTotalLabel
            // 
            classBTotalLabel.BorderStyle = BorderStyle.FixedSingle;
            classBTotalLabel.Location = new Point(89, 110);
            classBTotalLabel.Name = "classBTotalLabel";
            classBTotalLabel.Size = new Size(100, 23);
            classBTotalLabel.TabIndex = 5;
            classBTotalLabel.TextAlign = ContentAlignment.MiddleRight;
            // 
            // classCTotalLabel
            // 
            classCTotalLabel.BorderStyle = BorderStyle.FixedSingle;
            classCTotalLabel.Location = new Point(89, 159);
            classCTotalLabel.Name = "classCTotalLabel";
            classCTotalLabel.Size = new Size(100, 23);
            classCTotalLabel.TabIndex = 6;
            classCTotalLabel.TextAlign = ContentAlignment.MiddleRight;
            // 
            // totalLabel
            // 
            totalLabel.BorderStyle = BorderStyle.FixedSingle;
            totalLabel.Location = new Point(89, 210);
            totalLabel.Name = "totalLabel";
            totalLabel.Size = new Size(100, 23);
            totalLabel.TabIndex = 7;
            totalLabel.TextAlign = ContentAlignment.MiddleRight;
            // 
            // calculateButton
            // 
            calculateButton.Location = new Point(94, 355);
            calculateButton.Name = "calculateButton";
            calculateButton.Size = new Size(75, 35);
            calculateButton.TabIndex = 2;
            calculateButton.Text = "Calculate Revenue";
            calculateButton.UseVisualStyleBackColor = true;
            // 
            // clearButton
            // 
            clearButton.Location = new Point(331, 357);
            clearButton.Name = "clearButton";
            clearButton.Size = new Size(75, 33);
            clearButton.TabIndex = 3;
            clearButton.Text = "Clear";
            clearButton.UseVisualStyleBackColor = true;
            // 
            // exitButton
            // 
            exitButton.Location = new Point(562, 357);
            exitButton.Name = "exitButton";
            exitButton.Size = new Size(75, 33);
            exitButton.TabIndex = 4;
            exitButton.Text = "Exit";
            exitButton.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(exitButton);
            Controls.Add(clearButton);
            Controls.Add(calculateButton);
            Controls.Add(outputGroupBox);
            Controls.Add(inputGroupBox);
            Name = "Form1";
            Text = "Stadium Seating";
            Load += Form1_Load;
            inputGroupBox.ResumeLayout(false);
            inputGroupBox.PerformLayout();
            outputGroupBox.ResumeLayout(false);
            outputGroupBox.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox inputGroupBox;
        private GroupBox outputGroupBox;
        private Label instructionsLabel;
        private Label classAPromptLabel;
        private Label classCPromptLabel;
        private Label classBPromptLabel;
        private Label classBRevenueLabel;
        private Label classARevenueLabel;
        private TextBox classATextBox;
        private Label totalRevenueLabel;
        private Label classCRevenueLabel;
        private TextBox classCTextBox;
        private TextBox classBTextBox;
        private Label totalLabel;
        private Label classCTotalLabel;
        private Label classBTotalLabel;
        private Label classATotalLabel;
        private Button calculateButton;
        private Button clearButton;
        private Button exitButton;
    }
}
