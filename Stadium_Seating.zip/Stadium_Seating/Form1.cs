namespace Stadium_Seating
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Clear output labels when the form loads
        private void Form1_Load(object sender, EventArgs e)
        {
            classATotalLabel.Text = "";
            classBTotalLabel.Text = "";
            classCTotalLabel.Text = "";
            totalLabel.Text = "";
        }

        // Calculate ticket revenue
        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Ticket prices
            const int CLASS_A_PRICE = 15;
            const int CLASS_B_PRICE = 12;
            const int CLASS_C_PRICE = 9;

            // Input variables
            int numTicketsA;
            int numTicketsB;
            int numTicketsC;

            // Revenue variables
            int aTotal;
            int bTotal;
            int cTotal;
            int total;

            // Read and convert input
            numTicketsA = int.Parse(classATextBox.Text);
            numTicketsB = int.Parse(classBTextBox.Text);
            numTicketsC = int.Parse(classCTextBox.Text);

            // Calculate revenue
            aTotal = numTicketsA * CLASS_A_PRICE;
            bTotal = numTicketsB * CLASS_B_PRICE;
            cTotal = numTicketsC * CLASS_C_PRICE;

            // Calculate total revenue
            total = aTotal + bTotal + cTotal;

            // Display output (currency formatted)
            classATotalLabel.Text = aTotal.ToString("C");
            classBTotalLabel.Text = bTotal.ToString("C");
            classCTotalLabel.Text = cTotal.ToString("C");
            totalLabel.Text = total.ToString("C");
        }

        // Clear all inputs and outputs
        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear TextBoxes
            classATextBox.Clear();
            classBTextBox.Clear();
            classCTextBox.Clear();

            // Clear output Labels
            classATotalLabel.Text = "";
            classBTotalLabel.Text = "";
            classCTotalLabel.Text = "";
            totalLabel.Text = "";

            // Set focus back to first input
            classATextBox.Focus();
        }

        // Exit the application
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}