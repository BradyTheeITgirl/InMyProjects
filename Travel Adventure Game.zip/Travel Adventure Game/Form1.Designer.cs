﻿namespace Travel_Adventure_Game
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            locationLabel = new Label();
            descriptionLabel = new Label();
            statsLabel = new Label();
            eventLabel = new Label();
            travelButton = new Button();
            restButton = new Button();
            inventoryButton = new Button();
            inventoryListBox = new ListBox();
            SuspendLayout();
            // 
            // locationLabel
            // 
            locationLabel.BorderStyle = BorderStyle.FixedSingle;
            locationLabel.Location = new Point(40, 39);
            locationLabel.Name = "locationLabel";
            locationLabel.Size = new Size(300, 30);
            locationLabel.TabIndex = 0;
            locationLabel.Text = "Location";
            // 
            // descriptionLabel
            // 
            descriptionLabel.BorderStyle = BorderStyle.FixedSingle;
            descriptionLabel.Location = new Point(38, 73);
            descriptionLabel.Name = "descriptionLabel";
            descriptionLabel.Size = new Size(400, 80);
            descriptionLabel.TabIndex = 1;
            descriptionLabel.Text = "Description";
            // 
            // statsLabel
            // 
            statsLabel.BorderStyle = BorderStyle.FixedSingle;
            statsLabel.Location = new Point(38, 153);
            statsLabel.Name = "statsLabel";
            statsLabel.Size = new Size(200, 120);
            statsLabel.TabIndex = 2;
            statsLabel.Text = "Stats";
            // 
            // eventLabel
            // 
            eventLabel.BorderStyle = BorderStyle.FixedSingle;
            eventLabel.Location = new Point(38, 273);
            eventLabel.Name = "eventLabel";
            eventLabel.Size = new Size(400, 80);
            eventLabel.TabIndex = 3;
            eventLabel.Text = "Event";
            // 
            // travelButton
            // 
            travelButton.Location = new Point(518, 39);
            travelButton.Name = "travelButton";
            travelButton.Size = new Size(75, 23);
            travelButton.TabIndex = 4;
            travelButton.Text = "Travel";
            travelButton.UseVisualStyleBackColor = true;
            travelButton.Click += travelButton_Click;
            // 
            // restButton
            // 
            restButton.Location = new Point(518, 84);
            restButton.Name = "restButton";
            restButton.Size = new Size(75, 23);
            restButton.TabIndex = 5;
            restButton.Text = "Rest";
            restButton.UseVisualStyleBackColor = true;
            restButton.Click += restButton_Click;
            // 
            // inventoryButton
            // 
            inventoryButton.Location = new Point(518, 130);
            inventoryButton.Name = "inventoryButton";
            inventoryButton.Size = new Size(75, 23);
            inventoryButton.TabIndex = 6;
            inventoryButton.Text = "Inventory";
            inventoryButton.UseVisualStyleBackColor = true;
            inventoryButton.Click += inventoryButton_Click;
            // 
            // inventoryListBox
            // 
            inventoryListBox.FormattingEnabled = true;
            inventoryListBox.Location = new Point(528, 182);
            inventoryListBox.Name = "inventoryListBox";
            inventoryListBox.Size = new Size(200, 109);
            inventoryListBox.TabIndex = 7;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(inventoryListBox);
            Controls.Add(inventoryButton);
            Controls.Add(restButton);
            Controls.Add(travelButton);
            Controls.Add(eventLabel);
            Controls.Add(statsLabel);
            Controls.Add(descriptionLabel);
            Controls.Add(locationLabel);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Label locationLabel;
        private Label descriptionLabel;
        private Label statsLabel;
        private Label eventLabel;
        private Button travelButton;
        private Button restButton;
        private Button inventoryButton;
        private ListBox inventoryListBox;
    }
}
