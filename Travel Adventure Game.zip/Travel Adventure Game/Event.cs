﻿// ref: instructions used
// ChatGPT helped me organize the Travel Adventure Game classes, random event logic, and file I/O structure.

namespace TravelAdventureGame
{
    public class Event
    {
        public string Description { get; set; }
        public int HealthChange { get; set; }
        public int MoneyChange { get; set; }
        public int StaminaChange { get; set; }
        public int MoraleChange { get; set; }
        public string ItemReward { get; set; }

        public Event(string description, int healthChange, int moneyChange, int staminaChange, int moraleChange, string itemReward)
        {
            Description = description;
            HealthChange = healthChange;
            MoneyChange = moneyChange;
            StaminaChange = staminaChange;
            MoraleChange = moraleChange;
            ItemReward = itemReward;
        }
    }
}