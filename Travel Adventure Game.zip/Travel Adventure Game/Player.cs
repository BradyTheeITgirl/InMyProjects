﻿// ref: instructions used
// ChatGPT helped me organize the Travel Adventure Game classes, random event logic, and file I/O structure.

using System.Collections.Generic;

namespace TravelAdventureGame
{
    public class Player
    {
        public int Health { get; set; }
        public int Money { get; set; }
        public int Stamina { get; set; }
        public int Morale { get; set; }
        public int Progress { get; set; }

        public List<string> Inventory { get; set; }

        public Player()
        {
            Health = 100;
            Money = 75;
            Stamina = 100;
            Morale = 80;
            Progress = 0;
            Inventory = new List<string>();
            Inventory.Add("Map");
        }

        public bool IsAlive()
        {
            return Health > 0 && Stamina > 0 && Morale > 0;
        }

        public string GetStats()
        {
            return $"Health: {Health}\nMoney: ${Money}\nStamina: {Stamina}\nMorale: {Morale}\nProgress: {Progress}/5";
        }
    }
}