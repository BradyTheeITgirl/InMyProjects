﻿// ref: instructions used
// ChatGPT helped me organize the Travel Adventure Game classes, random event logic, and file I/O structure.

namespace TravelAdventureGame
{
    public class Location
    {
        public string Name { get; set; }
        public string Description { get; set; }

        public Location(string name, string description)
        {
            Name = name;
            Description = description;
        }

        public override string ToString()
        {
            return Name;
        }
    }
}