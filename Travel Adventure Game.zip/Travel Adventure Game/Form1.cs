// ref: instructions used
// ChatGPT helped me organize the Travel Adventure Game classes, random event logic, and file I/O structure.

using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;
using Travel_Adventure_Game;

namespace TravelAdventureGame
{
    public partial class Form1 : Form
    {
        private Player player;
        private List<Location> locations;
        private List<Event> eventsList;
        private Random rand;
        private int currentLocationIndex;
        private object descriptionLabel;
        private object statsLabel;
        private object inventoryListBox;
        private readonly object locationLabel;

        public Form1()
        {
            InitializeComponent();

            player = new Player();
            locations = new List<Location>();
            eventsList = new List<Event>();
            rand = new Random();
            currentLocationIndex = 0;

            LoadLocations();
            LoadEvents();
            UpdateDisplay(GetLocationLabel1());
        }

        private void InitializeComponent()
        {
            throw new NotImplementedException();
        }

        private void LoadLocations()
        {
            if (File.Exists("locations.txt"))
            {
                string[] lines = File.ReadAllLines("locations.txt");

                foreach (string line in lines)
                {
                    string[] parts = line.Split('|');

                    if (parts.Length == 2)
                    {
                        locations.Add(new Location(parts[0], parts[1]));
                    }
                }
            }
            else
            {
                locations.Add(new Location("Starting Village", "Your journey begins in a quiet village."));
                locations.Add(new Location("Forest Trail", "Tall trees surround the narrow trail."));
                locations.Add(new Location("Mountain Pass", "The air is cold and the path is steep."));
                locations.Add(new Location("River Crossing", "A rushing river blocks part of the road."));
                locations.Add(new Location("Desert Outpost", "The heat is intense, but shelter is nearby."));
                locations.Add(new Location("Final City", "You have reached the final destination."));
            }
        }

        private void LoadEvents()
        {
            if (File.Exists("events.txt"))
            {
                string[] lines = File.ReadAllLines("events.txt");

                foreach (string line in lines)
                {
                    string[] parts = line.Split('|');

                    if (parts.Length == 6)
                    {
                        eventsList.Add(new Event(
                            parts[0],
                            int.Parse(parts[1]),
                            int.Parse(parts[2]),
                            int.Parse(parts[3]),
                            int.Parse(parts[4]),
                            parts[5]));
                    }
                }
            }
            else
            {
                eventsList.Add(new Event("You found a small supply bag.", 0, 10, 5, 5, "Snack"));
                eventsList.Add(new Event("A storm slowed your travel.", -10, 0, -15, -5, "None"));
                eventsList.Add(new Event("A kind traveler gave you directions.", 0, 0, 0, 10, "Compass"));
                eventsList.Add(new Event("You paid for safe lodging.", 10, -15, 15, 5, "None"));
            }
        }

        private object GetLocationLabel1()
        {
            return locationLabel;
        }

        private void UpdateDisplay(object locationLabel)
        {
            Location currentLocation = locations[currentLocationIndex];
            locationLabel.Text = currentLocation.Name;
            descriptionLabel.text = currentLocation.Description;
            statsLabel.Text = player.GetStats();

            inventoryListBox.Items.Clear();

            foreach (string item in player.Inventory)
            {
                inventoryListBox.Items.Add(item);
            }
        }

        private void travelButton_Click(object sender, EventArgs e)
        {
            if (currentLocationIndex < locations.Count - 1)
            {
                currentLocationIndex++;
                player.Progress++;

                player.Stamina -= 10;
                player.Morale -= 3;

                TriggerRandomEvent();
                CheckGameStatus();
                UpdateDisplay(GetLocationLabel1());
            }
        }

        private void restButton_Click(object sender, EventArgs e)
        {
            if (player.Money >= 10)
            {
                player.Money -= 10;
                player.Health += 10;
                player.Stamina += 20;
                player.Morale += 5;

                eventLabel.Text = "You rested for the night. Health, stamina, and morale improved.";
            }
            else
            {
                eventLabel.Text = "You do not have enough money to rest.";
            }

            CheckGameStatus();
            UpdateDisplay(GetLocationLabel1());
        }

        private void inventoryButton_Click(object sender, EventArgs e)
        {
            if (player.Inventory.Count == 0)
            {
                MessageBox.Show("Your inventory is empty.");
            }
            else
            {
                string items = "";

                foreach (string item in player.Inventory)
                {
                    items += item + "\n";
                }

                MessageBox.Show(items, "Inventory");
            }
        }

        private void TriggerRandomEvent()
        {
            if (eventsList.Count > 0)
            {
                int index = rand.Next(eventsList.Count);
                Event gameEvent = eventsList[index];

                player.Health += gameEvent.HealthChange;
                player.Money += gameEvent.MoneyChange;
                player.Stamina += gameEvent.StaminaChange;
                player.Morale += gameEvent.MoraleChange;

                if (gameEvent.ItemReward != "None" && !player.Inventory.Contains(gameEvent.ItemReward))
                {
                    player.Inventory.Add(gameEvent.ItemReward);
                }

                eventLabel.Text = gameEvent.Description;
            }
        }

        private void CheckGameStatus()
        {
            if (!player.IsAlive())
            {
                MessageBox.Show("You lost! Your resources were depleted before reaching the final city.");
                DisableGameButtons();
            }
            else if (currentLocationIndex == locations.Count - 1)
            {
                MessageBox.Show("You win! You reached the Final City successfully.");
                SaveScore();
                DisableGameButtons();
            }
        }

        private void DisableGameButtons()
        {
            travelButton.Enabled = false;
            restButton.Enabled = false;
            inventoryButton.Enabled = false;
        }

        private void SaveScore()
        {
            using (StreamWriter outputFile = new StreamWriter("score.txt", true))
            {
                outputFile.WriteLine($"Final Score - Health: {player.Health}, Money: {player.Money}, Stamina: {player.Stamina}, Morale: {player.Morale}");
            }
        }
    }
}