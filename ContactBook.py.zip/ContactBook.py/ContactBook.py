# ------------------------------------------------------------
# Program Name: Contact Book
# File Name: ContactBook.py
# Author: Lauretta Brady
# Date: February 4, 2026
# Description:
# This program allows users to manage a contact book by
# adding, deleting, searching, and viewing contacts.
# Each contact can store multiple phone numbers, and
# contacts are saved to a file so they persist between runs.
# ------------------------------------------------------------

import json

FILE_NAME = "contacts.json"


def load_contacts():
    try:
        with open(FILE_NAME, "r") as f:
            return json.load(f)  # { "name": ["phone1", "phone2"] }
    except:
        return {}


def save_contacts(contacts):
    with open(FILE_NAME, "w") as f:
        json.dump(contacts, f, indent=2)


def display_menu():
    print("\n===== Contact Book =====")
    print("1. Add contact")
    print("2. Delete contact")
    print("3. Search contact")
    print("4. View contacts")
    print("5. Exit")


def add_contact(contacts):
    name = input("Name: ").strip().lower()
    phone = input("Phone: ").strip()

    if name == "" or phone == "":
        print("Name and phone cannot be blank.")
        return

    if name not in contacts:
        contacts[name] = []

    if phone in contacts[name]:
        print("That number is already saved for this contact.")
    else:
        contacts[name].append(phone)
        print("Contact saved.")


def delete_contact(contacts):
    name = input("Name to delete: ").strip().lower()

    if name not in contacts:
        print("Contact not found.")
        return

    # If only one number, remove the whole contact
    if len(contacts[name]) == 1:
        del contacts[name]
        print("Contact deleted.")
        return

    # Otherwise choose which number to delete
    print("\nNumbers:")
    for i, num in enumerate(contacts[name], start=1):
        print(f"{i}. {num}")
    print(f"{len(contacts[name]) + 1}. Delete ALL")

    try:
        choice = int(input("Choose: "))
        if 1 <= choice <= len(contacts[name]):
            contacts[name].pop(choice - 1)
            if len(contacts[name]) == 0:
                del contacts[name]
            print("Number deleted.")
        elif choice == len(contacts[name]) + 1:
            del contacts[name]
            print("Contact deleted.")
        else:
            print("Invalid choice.")
    except:
        print("Invalid input.")


def search_contact(contacts):
    name = input("Name to search: ").strip().lower()
    if name in contacts:
        print("Phone numbers:")
        for num in contacts[name]:
            print("-", num)
    else:
        print("Contact not found.")


def view_contacts(contacts):
    if not contacts:
        print("No contacts saved.")
        return

    print("\n--- Contacts ---")
    for name in sorted(contacts):
        print(name.title() + ": " + ", ".join(contacts[name]))


def main():
    contacts = load_contacts()

    while True:
        display_menu()
        choice = input("Option (1-5): ").strip()

        if choice == "1":
            add_contact(contacts)
            save_contacts(contacts)
        elif choice == "2":
            delete_contact(contacts)
            save_contacts(contacts)
        elif choice == "3":
            search_contact(contacts)
        elif choice == "4":
            view_contacts(contacts)
        elif choice == "5":
            save_contacts(contacts)
            print("Exiting Contact Book. Goodbye!")
            break
        else:
            print("Invalid option.")


if __name__ == "__main__":
    main()

